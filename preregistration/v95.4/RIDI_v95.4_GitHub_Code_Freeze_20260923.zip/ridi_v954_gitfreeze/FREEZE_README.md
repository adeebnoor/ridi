# RIDI Nature v95.4 preregistration code freeze

This directory freezes the reviewed P1-P6 code and small provenance records before any new P1-P6 model output. Large recovered historical data are not duplicated in this GitHub freeze; their exact SHA-256 values and OSF provenance are recorded in the preregistration draft and recovery verification.

The recovered registered contexts, pools and historical generations remain in the pre-registration artifact bundle and are validated against OSF txwdv.
