# P5 model pin provenance — v95.3

Frozen on 23 September 2026 before P5 generation. Each learned retrieval/reranking model is pinned to the full immutable Hugging Face commit shown by the model repository current `main` at freeze time.

| Model | Frozen revision | Source |
|---|---|---|
| `naver/splade-cocondenser-ensembledistil` | `49cf4c7b0db5b870a401ddf5e2669993ef3699c7` | https://huggingface.co/naver/splade-cocondenser-ensembledistil/commit/49cf4c7b0db5b870a401ddf5e2669993ef3699c7 |
| `facebook/contriever-msmarco` | `abe8c1493371369031bcb1e02acb754cf4e162fa` | https://huggingface.co/facebook/contriever-msmarco/commit/abe8c1493371369031bcb1e02acb754cf4e162fa |
| `intfloat/e5-small-v2` | `ffb93f3bd4047442299a41ebb6fa998a38507c52` | https://huggingface.co/intfloat/e5-small-v2/commit/ffb93f3bd4047442299a41ebb6fa998a38507c52 |
| `intfloat/e5-base-v2` | `f52bf8ec8c7124536f0efb74aca902b2995e5bcd` | https://huggingface.co/intfloat/e5-base-v2/commit/f52bf8ec8c7124536f0efb74aca902b2995e5bcd |
| `intfloat/e5-large-v2` | `f169b11e22de13617baa190a028a32f3493550b6` | https://huggingface.co/intfloat/e5-large-v2/commit/f169b11e22de13617baa190a028a32f3493550b6 |
| `BAAI/bge-small-en-v1.5` | `5c38ec7c405ec4b44b94cc5a9bb96e735b38267a` | https://huggingface.co/BAAI/bge-small-en-v1.5/commit/5c38ec7c405ec4b44b94cc5a9bb96e735b38267a |
| `BAAI/bge-base-en-v1.5` | `a5beb1e3e68b9ab74eb54cfd186867f64f240e1a` | https://huggingface.co/BAAI/bge-base-en-v1.5/commit/a5beb1e3e68b9ab74eb54cfd186867f64f240e1a |
| `BAAI/bge-large-en-v1.5` | `d4aa6901d3a41ba39fb536a557fa166f842b0e09` | https://huggingface.co/BAAI/bge-large-en-v1.5/commit/d4aa6901d3a41ba39fb536a557fa166f842b0e09 |
| `thenlper/gte-small` | `17e1f347d17fe144873b1201da91788898c639cd` | https://huggingface.co/thenlper/gte-small/commit/17e1f347d17fe144873b1201da91788898c639cd |
| `thenlper/gte-base` | `c078288308d8dee004ab72c6191778064285ec0c` | https://huggingface.co/thenlper/gte-base/commit/c078288308d8dee004ab72c6191778064285ec0c |
| `thenlper/gte-large` | `4bef63f39fcc5e2d6b0aae83089f307af4970164` | https://huggingface.co/thenlper/gte-large/commit/4bef63f39fcc5e2d6b0aae83089f307af4970164 |
| `cross-encoder/ms-marco-MiniLM-L6-v2` | `233902d25c440f23af6f7d6e94d2946bac0bee0a` | https://huggingface.co/cross-encoder/ms-marco-MiniLM-L6-v2/commit/233902d25c440f23af6f7d6e94d2946bac0bee0a |
| `cross-encoder/ms-marco-MiniLM-L12-v2` | `7b0235231ca2674cb8ca8f022859a6eba2b1c968` | https://huggingface.co/cross-encoder/ms-marco-MiniLM-L12-v2/commit/7b0235231ca2674cb8ca8f022859a6eba2b1c968 |
| `cross-encoder/ms-marco-TinyBERT-L2-v2` | `81d1926f67cb8eee2c2be17ca9f793c7c3bd20cc` | https://huggingface.co/cross-encoder/ms-marco-TinyBERT-L2-v2/commit/81d1926f67cb8eee2c2be17ca9f793c7c3bd20cc |
| `BAAI/bge-reranker-base` | `2cfc18c9415c912f9d8155881c133215df768a70` | https://huggingface.co/BAAI/bge-reranker-base/commit/2cfc18c9415c912f9d8155881c133215df768a70 |
| `BAAI/bge-reranker-large` | `55611d7bca2a7133960a6d3b71e083071bbfc312` | https://huggingface.co/BAAI/bge-reranker-large/commit/55611d7bca2a7133960a6d3b71e083071bbfc312 |
| `mixedbread-ai/mxbai-rerank-xsmall-v1` | `b5c6e9da73abc3711f593f705371cdbe9e0fe422` | https://huggingface.co/mixedbread-ai/mxbai-rerank-xsmall-v1/commit/b5c6e9da73abc3711f593f705371cdbe9e0fe422 |

## Generator and judge locks

- Open generator 1: `Qwen/Qwen3-8B` @ `b968826d9c46dd6066d109eabc6255188de91218` (inherited registered revision).
- Open generator 2: `allenai/OLMo-2-1124-7B-Instruct` @ `470b1fba1ae01581f270116362ee4aa1b97f4c84`.
- API generator: OpenAI `gpt-5.6-sol`; freeze/access date 2026-09-23. The returned provider model identifier and system fingerprint, when present, must be archived for every execution.
- Semantic-equivalence judge: `Qwen/Qwen3-32B` @ `9216db5781bf21249d130ec9da846c4624c16137`.
- Judge prompt: `08_New_Experiments/P5_SEMANTIC_JUDGE_PROMPT_v95.3.txt` (SHA-256 recorded in preregistration).
