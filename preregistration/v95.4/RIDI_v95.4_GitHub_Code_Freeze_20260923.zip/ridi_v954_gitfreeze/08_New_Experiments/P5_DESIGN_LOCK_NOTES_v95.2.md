# P5 design lock notes — v95.2 pre-registration repair

Status: **reviewed draft; no new outcome generation may start until the OSF registration is filed.**

## Changes made before registration

1. The P5 claim is explicitly conditional on a **prespecified finite roster**. The study does not estimate a super-population rate over all possible retrievers.
2. All configurations rerank the same BM25 top-100 pool. Therefore prevalence is conditional on that candidate pool; this must be stated in the manuscript.
3. The primary datasets are NQ, HotpotQA, FEVER and SciFact using previously unused queries. FiQA and TREC-COVID, if retained, are secondary transport analyses because their generation tasks are less constrained and are not counted in H-P5.
4. FEVER/SciFact generation uses the three-label set `SUPPORTS`, `REFUTES`, `NOT_ENOUGH_INFO`; the prior two-label fallback template was corrected before registration.
5. Generation prompts truncate each retrieved passage deterministically to 1,200 Unicode characters in P5. The runner now records prompt SHA-256 and the truncation value for every output.
6. The primary prevalence quantity is the share of qualified pair×dataset cells whose excess semantic disagreement reaches the registered threshold. A query-resampling bootstrap applies the same resampled query weights to all pairs in a dataset. The roster is held fixed, so its interval captures query-sampling uncertainty only.
7. The existing two-way query×pair bootstrap is retained only as a descriptive summary of the *mean* excess/disagreement and is not used to generalize to unseen retrieval systems.
8. Human-audit sample membership and annotation order are now reproducible from explicit seeds; no Python process-randomized `hash()` is used.

## Still blocking registration

- Exact P1/P5 API model IDs and access date(s).
- Exact second open generator ID and immutable revision.
- Immutable revisions for every Hugging Face retrieval/reranking model in the P5 roster.
- Exact registered scorer file for the 800-query panel and its SHA-256.
- Exact registered prompt/context export and archived registered generations for P1-P4/P2 byte-identity check.
- Semantic-equivalence judge model and frozen judge prompt.
- KAU determination for the two P4 annotators.
- P6 KEV snapshot date/hash and confirmation whether OSF 7cah9 prospectively locks v4→v5.
- Git commit containing the final pre-registration code.
