#!/usr/bin/env python3
"""P4. Do the exchanged grade-zero passages carry answer-relevant information?

Stages
  judge    Two LLM judges from different model families label every exchanged passage (removed from or added to the
           context) as informative (YES) or not (NO). Gold-answer strings are also detected for QA tasks.
  export   Draws a blinded random sample of passages (default 200) for two human annotators (CSV, one per annotator).
  analyze  Agreement (Cohen's kappa) among judges and humans; the 'clean' query subset in which every exchanged passage
           is judged uninformative by both judges and contains no gold string; correctness-change rate in the clean and
           non-clean subsets with stratified bootstrap intervals.

Human annotation requires the institutional determination for annotators before it starts.

Example:
  python p4_semantic_audit.py --stage judge --contexts data/contexts_800.jsonl --out results/p4 \
      --judge1 openai:<model id> --judge2 anthropic:<model id>
  python p4_semantic_audit.py --stage export --contexts data/contexts_800.jsonl --out results/p4
  python p4_semantic_audit.py --stage analyze --contexts data/contexts_800.jsonl --out results/p4 \
      --generations results/p2_qwen8b/generations.jsonl --regime fixed:16
"""
import argparse
import csv
import random
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from ridi_exp import stats
from ridi_exp.backends import make_backend
from ridi_exp.io import append_jsonl, read_jsonl
from ridi_exp.scoring import normalize

JUDGE_PROMPT = (
    "You are auditing evidence for a {kind}.\n{label}: {question}\n\nPassage:\n{passage}\n\n"
    "Does this passage contain any information that would help {goal}, including partial, indirect or misleading "
    "evidence that a reader could use? Reply with exactly one word: YES or NO."
)


def exchanged(contexts):
    by = defaultdict(dict)
    for c in contexts:
        if c.get('draw', 0) == 0:
            by[c['qid']][c['condition']] = c
    rows = []
    for q, d in by.items():
        if 'reference' not in d or 'random' not in d:
            continue
        ref_ids = {p['docid'] for p in d['reference']['passages']}; ran_ids = {p['docid'] for p in d['random']['passages']}
        c = d['reference']
        for p in d['reference']['passages']:
            if p['docid'] not in ran_ids:
                rows.append((c, p, 'removed'))
        for p in d['random']['passages']:
            if p['docid'] not in ref_ids:
                rows.append((c, p, 'added'))
    return rows


def judge_prompt(c, p):
    if c['task'] == 'qa':
        return JUDGE_PROMPT.format(kind='question', label='Question', question=c['question'], passage=p['text'], goal='answer the question')
    return JUDGE_PROMPT.format(kind='claim', label='Claim', question=c['question'], passage=p['text'], goal='support or refute the claim')


def parse_yes_no(raw):
    t = raw.strip().upper()
    return 1 if t.startswith('YES') else 0 if t.startswith('NO') else -1


def gold_in(c, p):
    if c['task'] != 'qa':
        return 0
    txt = normalize(p['text'])
    return int(any(normalize(g) and f' {normalize(g)} ' in f' {txt} ' for g in c['gold']))


def stage_judge(a, ctx):
    rows = exchanged(ctx)
    out = a.out / 'passage_labels.jsonl'
    done = {(r['qid'], r['docid'], r['role'], r['judge']) for r in read_jsonl(out)}
    for jname, spec in (('judge1', a.judge1), ('judge2', a.judge2)):
        kind, model = spec.split(':', 1)
        be = make_backend(kind, model) if kind == 'mock' else make_backend(kind, model, max_new_tokens=8, workers=a.workers)
        todo = [(c, p, role) for c, p, role in rows if (c['qid'], p['docid'], role, jname) not in done]
        for i in range(0, len(todo), 256):
            chunk = todo[i:i + 256]
            outs = be.generate_batches([[judge_prompt(c, p) for c, p, _ in chunk]])[0]
            append_jsonl(out, [{'qid': c['qid'], 'dataset': c['dataset'], 'docid': p['docid'], 'role': role, 'judge': jname,
                                'model': model, 'raw': o, 'informative': parse_yes_no(o), 'gold_string': gold_in(c, p)}
                               for (c, p, role), o in zip(chunk, outs)])
        print(f'{jname}: {len(todo)} passages judged')


def stage_export(a, ctx):
    rows = exchanged(ctx)
    uniq = {}
    for c, p, role in rows:
        uniq.setdefault((c['qid'], p['docid']), (c, p))
    keys = sorted(uniq); random.Random(a.seed).shuffle(keys); keys = keys[:a.n_human]
    manifest = {'seed': a.seed, 'n_requested': a.n_human, 'n_sampled': len(keys),
                'sampled_item_ids': [f'{q}::{d}' for q, d in keys],
                'annotation_order_seeds': {'annotator_A': a.seed + 1, 'annotator_B': a.seed + 2}}
    (a.out / 'human_audit_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    for ann in ('annotator_A', 'annotator_B'):
        path = a.out / f'human_audit_{ann}.csv'; path.parent.mkdir(parents=True, exist_ok=True)
        order = list(keys); random.Random(manifest['annotation_order_seeds'][ann]).shuffle(order)
        with open(path, 'w', newline='', encoding='utf-8') as fh:
            w = csv.writer(fh); w.writerow(['item_id', 'question_or_claim', 'passage', 'informative_YES_or_NO', 'notes'])
            for q, d in order:
                c, p = uniq[(q, d)]
                w.writerow([f'{q}::{d}', c['question'], p['text'], '', ''])
    print(f'exported {len(keys)} items for two annotators to {a.out}')


def stage_analyze(a, ctx):
    labels = read_jsonl(a.out / 'passage_labels.jsonl')
    lab = defaultdict(dict); gold = {}
    for r in labels:
        lab[(r['qid'], r['docid'])][r['judge']] = r['informative']; gold[(r['qid'], r['docid'])] = r['gold_string']
    pairs = [v for v in lab.values() if 'judge1' in v and 'judge2' in v and v['judge1'] >= 0 and v['judge2'] >= 0]
    S = {'experiment': 'P4', 'n_passages_judged': len(lab), 'judge_unparsed': sum(1 for r in labels if r['informative'] < 0),
         'judge_kappa': stats.cohen_kappa([v['judge1'] for v in pairs], [v['judge2'] for v in pairs]) if pairs else None,
         'informative_rate_judge1': float(np.mean([v['judge1'] for v in pairs])) if pairs else None,
         'informative_rate_judge2': float(np.mean([v['judge2'] for v in pairs])) if pairs else None}
    # human agreement
    hum = {}
    for ann in ('annotator_A', 'annotator_B'):
        p = a.out / f'human_audit_{ann}.csv'
        if p.exists():
            with open(p, encoding='utf-8') as fh:
                hum[ann] = {r['item_id']: (1 if r['informative_YES_or_NO'].strip().upper().startswith('Y') else 0)
                            for r in csv.DictReader(fh) if r['informative_YES_or_NO'].strip()}
    if len(hum) == 2:
        common = sorted(set(hum['annotator_A']) & set(hum['annotator_B']))
        S['human_n'] = len(common)
        S['human_kappa'] = stats.cohen_kappa([hum['annotator_A'][i] for i in common], [hum['annotator_B'][i] for i in common])
        both = [i for i in common if hum['annotator_A'][i] == hum['annotator_B'][i]]
        for j in ('judge1', 'judge2'):
            ids = [i for i in both if j in lab.get(tuple(i.split('::', 1)), {})]
            S[f'human_consensus_vs_{j}_kappa'] = stats.cohen_kappa([hum['annotator_A'][i] for i in ids], [lab[tuple(i.split('::', 1))][j] for i in ids]) if ids else None
            # false-negative rate of the judge on human-informative passages: the error that matters for the clean subset
            pos = [i for i in ids if hum['annotator_A'][i] == 1]
            S[f'{j}_miss_rate_on_human_informative'] = float(np.mean([lab[tuple(i.split('::', 1))][j] == 0 for i in pos])) if pos else None
    # clean subset and change rates
    per_query = defaultdict(list)
    for (q, d), v in lab.items():
        per_query[q].append(int(v.get('judge1', 1) == 0 and v.get('judge2', 1) == 0 and gold.get((q, d), 0) == 0))
    clean = {q for q, v in per_query.items() if all(v)}
    if a.generations:
        res = [r for r in read_jsonl(a.generations) if r['batch_regime'] == a.regime and r.get('run', 0) == 0 and r.get('draw', 0) == 0]
        by = defaultdict(dict)
        for r in res:
            by[r['qid']][r['condition']] = r
        change = {q: int(v['reference']['correct'] != v['random']['correct']) for q, v in by.items() if 'reference' in v and 'random' in v}
        ds = {q: v['reference']['dataset'] for q, v in by.items() if 'reference' in v}
        for name, subset in (('clean', clean), ('not_clean', set(change) - clean), ('all', set(change))):
            vals = defaultdict(list)
            for q in subset & set(change):
                vals[ds[q]].append(change[q])
            if vals:
                lo, hi = stats.stratified_bootstrap_macro(vals, n_boot=20_000)
                S[f'change_{name}'] = {'n': sum(len(v) for v in vals.values()), 'pooled': stats.rate(sum(vals.values(), [])),
                                       'macro': stats.macro(vals), 'macro_ci95': (lo, hi),
                                       'n_by_dataset': {k: len(v) for k, v in vals.items()}}
    S['n_clean_queries'] = len(clean); S['n_queries_with_exchanges'] = len(per_query)
    from ridi_exp.cli import dump
    dump(S, a.out / 'P4_summary.json')
    print({k: S[k] for k in S if k.startswith('change_') or k in ('judge_kappa', 'n_clean_queries')})


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--stage', choices=['judge', 'export', 'analyze'], required=True)
    ap.add_argument('--contexts', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--judge1', default='mock:judge-a'); ap.add_argument('--judge2', default='mock:judge-b')
    ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--n-human', type=int, default=200); ap.add_argument('--seed', type=int, default=20260926)
    ap.add_argument('--generations', type=Path, default=None); ap.add_argument('--regime', default='fixed:16')
    a = ap.parse_args(); ctx = read_jsonl(a.contexts)
    {'judge': stage_judge, 'export': stage_export, 'analyze': stage_analyze}[a.stage](a, ctx)


if __name__ == '__main__':
    main()
