from __future__ import annotations
import re, unicodedata

_CIT=re.compile(r"\[(\d+)\]")
_LABEL_RE=re.compile(r"^\s*(SUPPORTS|REFUTES|NOT(?:_|\s+|-)+ENOUGH(?:_|\s+|-)+INFO)\b",re.I)

def strip_citations(s:str)->str:
    return _CIT.sub(" ",s)

def normalize_qa(s:str)->str:
    s=unicodedata.normalize("NFKC",strip_citations(s)).lower().strip()
    s=re.sub(r"\b(a|an|the)\b"," ",s)
    s=re.sub(r"[^\w\s]"," ",s,flags=re.UNICODE)
    return re.sub(r"\s+"," ",s).strip()

def canonical_label(ans:str,labels:list[str])->str:
    # Frozen primary parser: the verdict must occur at the start, as required by the prompt.
    m=_LABEL_RE.match(strip_citations(ans).strip())
    if not m:return "UNPARSEABLE"
    x=re.sub(r"[\s-]+","_",m.group(1).upper())
    return x if x in set(labels) else "UNPARSEABLE"

def canonical_answer(ans:str,task:str,labels:list[str]|None=None)->str:
    if task=="qa":return normalize_qa(ans)
    if task=="classification":return canonical_label(ans,labels or [])
    raise ValueError(task)

def qa_exact_correct(ans:str,gold:dict)->bool:
    pred=normalize_qa(ans)
    accepted={normalize_qa(str(x)) for x in gold.get("answers",[]) if normalize_qa(str(x))}
    return bool(pred) and pred in accepted

def qa_contains_correct(ans:str,gold:dict)->bool:
    pred=normalize_qa(ans)
    accepted=[normalize_qa(str(x)) for x in gold.get("answers",[])]
    accepted=[x for x in accepted if x]
    return bool(pred) and any(x in pred for x in accepted)

def is_correct(ans:str,gold:dict,task:str,labels:list[str]|None=None)->bool:
    if task=="qa":return qa_exact_correct(ans,gold)
    if task=="classification":
        pred=canonical_label(ans,labels or [])
        accepted={str(x).upper().replace(" ","_").replace("-","_") for x in gold.get("labels",[])}
        return pred in accepted
    raise ValueError(task)

def is_correct_sensitivity(ans:str,gold:dict,task:str,labels:list[str]|None=None)->bool:
    if task=="qa":return qa_contains_correct(ans,gold)
    return is_correct(ans,gold,task,labels)

def is_refusal(ans:str)->bool:
    n=normalize_qa(ans)
    return n=="insufficient" or n.startswith("not enough info")

def citations(ans:str)->list[int]:
    return sorted({int(x) for x in _CIT.findall(ans)})
