QA_PROMPT = (
    "Answer using ONLY the numbered passages below. "
    "If the passages do not contain the answer, reply exactly: INSUFFICIENT. "
    "Otherwise return ONLY the shortest answer span, followed by the supporting passage citation(s) as [n]. "
    "Do not add an explanation.\n\n"
    "{passages}\n\nQuestion: {query}\nAnswer:"
)

CLASSIFICATION_PROMPT = (
    "Evaluate the claim using ONLY the numbered passages below. "
    "The FIRST token must be exactly one of: SUPPORTS, REFUTES, NOT_ENOUGH_INFO. "
    "After that token, give at most one short sentence and cite the passage number(s) used as [n].\n\n"
    "{passages}\n\nClaim: {query}\nVerdict:"
)

def get_prompt(task:str)->str:
    if task=="qa":return QA_PROMPT
    if task=="classification":return CLASSIFICATION_PROMPT
    raise ValueError(task)
