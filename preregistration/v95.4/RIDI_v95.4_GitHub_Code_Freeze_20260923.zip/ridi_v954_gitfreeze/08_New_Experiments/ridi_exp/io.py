"""Input/output schema shared by all new experiments.

Context file (JSONL), one line per (query, condition, draw):
{
  "qid": "scifact-275",            # unique query id
  "dataset": "scifact",            # nq | hotpotqa | fever | scifact | ...
  "task": "verdict" | "qa",        # scoring family
  "question": "...",               # query or claim text
  "gold": ["SUPPORTS"] | ["answer", "alias", ...],
  "condition": "reference" | "random" | "reorder" | "random_d1" ... ,
  "draw": 0,                        # replacement draw index (0 = registered draw)
  "passages": [{"docid": "...", "text": "...", "grade": 0|1|2}, ...],   # in rank order
  "prompt": "..."                  # OPTIONAL: exact frozen prompt string; if absent, prompts.build_prompt is used
}

Result file (JSONL): the context keys qid/dataset/condition/draw plus
{"model": ..., "run": ..., "batch_regime": ..., "raw": ..., "canonical": ..., "correct": 0|1, "meta": {...}}

Write results incrementally so interrupted runs resume without regenerating finished items.
"""
import json
from pathlib import Path


def read_jsonl(path):
    path = Path(path)
    if not path.exists():
        return []
    with open(path, encoding='utf-8') as fh:
        return [json.loads(line) for line in fh if line.strip()]


def append_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a', encoding='utf-8') as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False) + '\n')


def result_key(r):
    return (r['qid'], r['condition'], r.get('draw', 0), r.get('model'), r.get('run', 0), r.get('batch_regime', 'default'))


def done_keys(path):
    return {result_key(r) for r in read_jsonl(path)}


def validate_context(c):
    need = ['qid', 'dataset', 'task', 'question', 'gold', 'condition', 'passages']
    missing = [k for k in need if k not in c]
    if missing:
        raise ValueError(f"context {c.get('qid')} missing {missing}")
    if c['task'] not in ('qa', 'verdict'):
        raise ValueError(f"unknown task {c['task']}")
    for p in c['passages']:
        if 'text' not in p or 'docid' not in p:
            raise ValueError(f"passage without text/docid in {c['qid']}")
    return c


def grade_vector(c):
    return tuple(p.get('grade', 0) for p in c['passages'])
