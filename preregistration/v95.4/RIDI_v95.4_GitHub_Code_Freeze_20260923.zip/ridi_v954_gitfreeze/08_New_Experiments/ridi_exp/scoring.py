"""Scoring. For the registered 800-query panel, import the FROZEN scorer from the archive instead (see load_scorer).
The functions here reproduce the documented rules (normalized exact match after citation removal; first-token verdict
parser, strict and wrapper-tolerant) for new data and tests."""
import importlib.util
import re
import string

VERDICTS = ('SUPPORTS', 'REFUTES', 'NOT ENOUGH INFO')


def strip_citations(s):
    return re.sub(r'\[\d+(?:,\s*\d+)*\]', '', s)


def normalize(s):
    s = strip_citations(s).lower()
    s = ''.join(ch for ch in s if ch not in set(string.punctuation))
    s = re.sub(r'\b(a|an|the)\b', ' ', s)
    return ' '.join(s.split())


def qa_canonical(raw):
    first = raw.strip().split('\n')[0]
    first = re.sub(r'^(answer|final answer)\s*[:\-]\s*', '', first, flags=re.I)
    return normalize(first)


def qa_correct(raw, gold, contains=False):
    c = qa_canonical(raw)
    golds = [normalize(g) for g in gold]
    if contains:
        return int(any(g and g in c for g in golds))
    return int(c in golds)


def verdict_canonical(raw, tolerant=False):
    t = raw.strip()
    if tolerant:
        t = re.sub(r'^[\*\s"\'`]*(verdict|answer|label)\s*[:\-]\s*', '', t, flags=re.I)
        t = t.lstrip('*"\'` ')
    up = t.upper()
    for v in VERDICTS:
        if up.startswith(v) or up.startswith(v.rstrip('S')):
            return v
    return 'UNPARSED'


def verdict_correct(raw, gold, tolerant=False):
    return int(verdict_canonical(raw, tolerant) == gold[0].upper())


def score(context, raw, tolerant=False, contains=False):
    if context['task'] == 'qa':
        return qa_canonical(raw), qa_correct(raw, context['gold'], contains)
    return verdict_canonical(raw, tolerant), verdict_correct(raw, context['gold'], tolerant)


def load_scorer(path):
    """Load the frozen scorer without modifying it.

    Preferred interface is score(context, raw). The registered RIDI-RAG-v2 scorer predates
    this extension and exposes canonical_answer()/is_correct() instead; in that case this
    function supplies a thin schema adapter while all scoring decisions remain inside the
    byte-identical registered module.
    """
    spec = importlib.util.spec_from_file_location('frozen_scorer', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if hasattr(mod, 'score'):
        return mod.score
    required = ('canonical_answer', 'is_correct')
    if all(hasattr(mod, name) for name in required):
        def registered_adapter(context, raw):
            task = 'qa' if context['task'] == 'qa' else 'classification'
            labels = None if task == 'qa' else ['SUPPORTS', 'REFUTES', 'NOT_ENOUGH_INFO']
            gold = {'answers': context['gold']} if task == 'qa' else {'labels': context['gold']}
            canonical = mod.canonical_answer(raw, task, labels)
            correct = mod.is_correct(raw, gold, task, labels)
            return canonical, int(correct)
        return registered_adapter
    raise AttributeError('frozen scorer must expose score() or registered canonical_answer()/is_correct()')
