"""Analysis of paired contrasts: reference vs exchanged contexts, with a repeat or execution floor."""
from collections import defaultdict

from . import stats


def index(results):
    """{(model, run, regime, condition, draw): {qid: result}}"""
    idx = defaultdict(dict)
    for r in results:
        idx[(r['model'], r.get('run', 0), r.get('batch_regime', 'default'), r['condition'], r.get('draw', 0))][r['qid']] = r
    return idx


def contrast(a, b, dataset_of=None):
    """Correctness change and canonical change between two {qid: result} maps, macro and pooled."""
    q = sorted(set(a) & set(b))
    ds = defaultdict(list); dc = defaultdict(list)
    corr_a, corr_b = [], []
    for k in q:
        d = (dataset_of or {}).get(k, a[k]['dataset'])
        ds[d].append(int(a[k]['correct'] != b[k]['correct']))
        dc[d].append(int(a[k]['canonical'] != b[k]['canonical']))
        corr_a.append(a[k]['correct']); corr_b.append(b[k]['correct'])
    out = {'n': len(q),
           'correctness_change_macro': stats.macro(ds), 'correctness_change_pooled': stats.rate(sum(ds.values(), [])),
           'canonical_change_macro': stats.macro(dc), 'canonical_change_pooled': stats.rate(sum(dc.values(), [])),
           'by_dataset': {d: {'n': len(v), 'correctness_change': stats.rate(v), 'canonical_change': stats.rate(dc[d])} for d, v in ds.items()},
           'paired_accuracy': stats.paired_accuracy(corr_a, corr_b)}
    return out, ds, dc


def contrast_with_floor(idx, model, cond_a, cond_b, run_regime_main, run_regime_repeat, n_boot=100_000):
    """Primary contrast (cond_a vs cond_b at run_regime_main) with a floor from repeating cond_a
    at run_regime_repeat. run_regime_* = (run, regime)."""
    ra, ga = run_regime_main; rb, gb = run_regime_repeat
    A = idx[(model, ra, ga, cond_a, 0)]; B = idx[(model, ra, ga, cond_b, 0)]; A2 = idx[(model, rb, gb, cond_a, 0)]
    main, ds_main, dc_main = contrast(A, B)
    floor, ds_floor, dc_floor = contrast(A, A2)
    lo, hi = stats.stratified_bootstrap_macro(ds_main, n_boot=n_boot)
    change_q = {k: int(A[k]['correct'] != B[k]['correct']) for k in set(A) & set(B)}
    floor_q = {k: int(A[k]['correct'] != A2[k]['correct']) for k in set(A) & set(A2)}
    canon_change_q = {k: int(A[k]['canonical'] != B[k]['canonical']) for k in set(A) & set(B)}
    canon_floor_q = {k: int(A[k]['canonical'] != A2[k]['canonical']) for k in set(A) & set(A2)}
    strata = {k: A[k]['dataset'] for k in A}
    pa = main['paired_accuracy']
    return {'model': model, 'main': main, 'main_macro_ci95': (lo, hi), 'floor': floor,
            'excess_correctness': stats.excess_over_floor(change_q, floor_q, strata=strata),
            'excess_canonical': stats.excess_over_floor(canon_change_q, canon_floor_q, strata=strata),
            'tost_p_3pp': stats.tost_p(pa['diff'], pa['se'], 0.03), 'tost_p_5pp': stats.tost_p(pa['diff'], pa['se'], 0.05)}
