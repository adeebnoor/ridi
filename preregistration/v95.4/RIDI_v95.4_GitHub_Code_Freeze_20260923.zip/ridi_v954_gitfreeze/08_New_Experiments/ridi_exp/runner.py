"""Shared generation runner with resumable output and explicit batch regimes.

Batch regimes (for local models; API backends ignore batching):
  single             one prompt per forward pass
  fixed:N            deterministic order (qid, condition, draw), chunks of N
  shuffled:N:SEED    random permutation with SEED, chunks of N (changes batch companions)
"""
import random
import time
import hashlib

from .io import append_jsonl, done_keys, result_key, validate_context
from .prompts import build_prompt
from . import scoring


def arrange(items, regime):
    if regime == 'single':
        return [[x] for x in items]
    parts = regime.split(':')
    n = int(parts[1])
    items = list(items)
    if parts[0] == 'fixed':
        items.sort(key=lambda x: (x['qid'], x['condition'], x.get('draw', 0)))
    elif parts[0] == 'shuffled':
        random.Random(int(parts[2])).shuffle(items)
    else:
        raise ValueError(regime)
    return [items[i:i + n] for i in range(0, len(items), n)]


def run_generation(contexts, backend, out_path, run=0, regime='fixed:16', scorer=None, tolerant=False,
                   max_chars=None, flush_every=64, log=print):
    """Generate for every context not yet in out_path, score, and append results. Returns number generated."""
    scorer = scorer or (lambda c, raw: scoring.score(c, raw, tolerant=tolerant))
    model = backend.meta.get('model', backend.name)
    done = done_keys(out_path)
    todo = []
    for c in contexts:
        validate_context(c)
        key = (c['qid'], c['condition'], c.get('draw', 0), model, run, regime)
        if key not in done:
            todo.append(c)
    if not todo:
        log(f'[{model} run {run} {regime}] nothing to do'); return 0
    batches = arrange(todo, regime)
    t0 = time.time(); n = 0; buf = []
    step = max(1, flush_every // max(1, len(batches[0])))
    for i in range(0, len(batches), step):
        chunk = batches[i:i + step]
        built = [[build_prompt(c, max_chars) for c in b] for b in chunk]
        prompts = [[x[0] for x in bb] for bb in built]
        outs = backend.generate_batches(prompts)
        errors = 0
        for b, bb, ob in zip(chunk, built, outs):
            for c, (prompt_text, prompt_source), raw in zip(b, bb, ob):
                if str(raw).startswith('__ERROR__'):
                    errors += 1  # not written: retried on the next invocation
                    continue
                canon, corr = scorer(c, raw)
                buf.append({'qid': c['qid'], 'dataset': c['dataset'], 'condition': c['condition'], 'draw': c.get('draw', 0),
                            'model': model, 'run': run, 'batch_regime': regime, 'raw': raw, 'canonical': canon,
                            'correct': int(corr), 'prompt_source': prompt_source,
                            'prompt_sha256': hashlib.sha256(prompt_text.encode('utf-8')).hexdigest(),
                            'prompt_max_chars_per_passage': max_chars,
                            'config': c.get('config'), 'meta': backend.meta})
        append_jsonl(out_path, buf); n += len(buf); buf = []
        log(f'[{model} run {run} {regime}] {n}/{len(todo)} ({time.time() - t0:.0f}s)' + (f'; {errors} API errors left for retry' if errors else ''))
    return n
