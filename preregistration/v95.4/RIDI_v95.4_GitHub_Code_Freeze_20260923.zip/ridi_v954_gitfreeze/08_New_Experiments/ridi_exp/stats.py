"""Statistics used by all new experiments. Pure numpy/scipy; unit-tested in tests/test_stats.py."""
import math
from collections import defaultdict

import numpy as np
from scipy.stats import binomtest, norm

Z90 = 1.6448536269514722
Z95 = 1.959963984540054


def rate(xs):
    xs = list(xs)
    return sum(xs) / len(xs) if xs else float('nan')


def macro(values_by_dataset):
    """Equal-dataset-weight mean of per-dataset rates. values_by_dataset: {dataset: [0/1,...]}"""
    return float(np.mean([rate(v) for v in values_by_dataset.values()]))


def stratified_bootstrap_macro(values_by_dataset, n_boot=100_000, seed=20260902, alpha=0.05):
    rng = np.random.default_rng(seed)
    arrays = {d: np.asarray(v, dtype=float) for d, v in values_by_dataset.items()}
    boots = np.zeros(n_boot)
    for d, a in arrays.items():
        idx = rng.integers(0, len(a), size=(n_boot, len(a)))
        boots += a[idx].mean(axis=1)
    boots /= len(arrays)
    return float(np.quantile(boots, alpha / 2)), float(np.quantile(boots, 1 - alpha / 2))


def paired_accuracy(ref_correct, var_correct):
    """Paired accuracy difference (variant - reference) with Wald SE, McNemar exact P."""
    ref = np.asarray(ref_correct); var = np.asarray(var_correct); n = len(ref)
    c2w = int(((ref == 1) & (var == 0)).sum()); w2c = int(((ref == 0) & (var == 1)).sum())
    d = (w2c - c2w) / n
    se = math.sqrt(max((c2w + w2c) - (w2c - c2w) ** 2 / n, 0)) / n
    p = binomtest(c2w, c2w + w2c).pvalue if c2w + w2c else 1.0
    return {'n': n, 'correct_to_wrong': c2w, 'wrong_to_correct': w2c, 'diff': d, 'se': se,
            'ci90': (d - Z90 * se, d + Z90 * se), 'mcnemar_p': p}


def tost_p(diff, se, margin):
    if se == 0:
        return 0.0 if abs(diff) < margin else 1.0
    return max(1 - norm.cdf((diff + margin) / se), norm.cdf((diff - margin) / se))


def paired_tost(x, y, margin, alpha=0.05):
    """Two one-sided paired t-tests for per-query metric vectors (e.g. nDCG@10 of two retrievers)."""
    from scipy.stats import t as tdist
    d = np.asarray(x, float) - np.asarray(y, float); n = len(d)
    m = d.mean(); s = d.std(ddof=1) / math.sqrt(n) if n > 1 else 0.0
    if s == 0:
        return {'mean_diff': m, 'p': 0.0 if abs(m) < margin else 1.0, 'equivalent': abs(m) < margin, 'ci90': (m, m)}
    p_low = 1 - tdist.cdf((m + margin) / s, n - 1)
    p_high = tdist.cdf((m - margin) / s, n - 1)
    p = max(p_low, p_high)
    q = tdist.ppf(1 - alpha, n - 1)
    return {'mean_diff': float(m), 'p': float(p), 'equivalent': bool(p < alpha), 'ci90': (float(m - q * s), float(m + q * s))}


def holm(pvals):
    """Holm step-down adjusted p-values (same order as input)."""
    p = np.asarray(pvals, float); order = np.argsort(p); m = len(p)
    adj = np.empty(m); running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * p[i]); adj[i] = min(running, 1.0)
    return adj.tolist()


def wilson(x, n, z=Z95):
    if n == 0:
        return (float('nan'), float('nan'))
    ph = x / n; den = 1 + z * z / n
    centre = (ph + z * z / (2 * n)) / den
    half = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / den
    return (max(0.0, centre - half), min(1.0, centre + half))


def excess_over_floor(change_by_query, floor_by_query, n_boot=20_000, seed=20260923, strata=None):
    """Excess disagreement: mean(change) - mean(floor), paired by query, with (stratified) bootstrap interval.
    change_by_query / floor_by_query: {qid: 0/1 or rate}; strata: {qid: dataset} for stratified resampling."""
    q = sorted(set(change_by_query) & set(floor_by_query))
    c = np.array([change_by_query[k] for k in q], float); f = np.array([floor_by_query[k] for k in q], float)
    est = float(c.mean() - f.mean())
    rng = np.random.default_rng(seed)
    if strata:
        groups = defaultdict(list)
        for i, k in enumerate(q): groups[strata[k]].append(i)
        groups = [np.array(v) for v in groups.values()]
        boots = []
        for _ in range(n_boot):
            idx = np.concatenate([g[rng.integers(0, len(g), len(g))] for g in groups])
            boots.append(c[idx].mean() - f[idx].mean())
    else:
        idx = rng.integers(0, len(q), size=(n_boot, len(q)))
        boots = c[idx].mean(axis=1) - f[idx].mean(axis=1)
    boots = np.asarray(boots)
    return {'n_queries': len(q), 'change': float(c.mean()), 'floor': float(f.mean()), 'excess': est,
            'ci95': (float(np.quantile(boots, .025)), float(np.quantile(boots, .975)))}


def two_way_cluster_bootstrap(rows, value_key, unit_a='qid', unit_b='pair', n_boot=5_000, seed=20260924):
    """Pigeonhole (two-way) cluster bootstrap for a mean over rows indexed by two crossed factors
    (queries x retriever pairs). Returns point estimate and percentile 95% interval."""
    rng = np.random.default_rng(seed)
    A = sorted({r[unit_a] for r in rows}); B = sorted({r[unit_b] for r in rows})
    ai = {a: i for i, a in enumerate(A)}; bi = {b: i for i, b in enumerate(B)}
    ra = np.array([ai[r[unit_a]] for r in rows]); rb = np.array([bi[r[unit_b]] for r in rows]); v = np.array([r[value_key] for r in rows], float)
    est = float(v.mean()); boots = []
    for _ in range(n_boot):
        wa = np.bincount(rng.integers(0, len(A), len(A)), minlength=len(A))
        wb = np.bincount(rng.integers(0, len(B), len(B)), minlength=len(B))
        w = wa[ra] * wb[rb]
        if w.sum() > 0:
            boots.append(float((w * v).sum() / w.sum()))
    return {'estimate': est, 'ci95': (float(np.quantile(boots, .025)), float(np.quantile(boots, .975))), 'n_rows': len(rows), 'n_a': len(A), 'n_b': len(B)}



def fixed_roster_pair_share_bootstrap(rows, value_key='excess', threshold=0.05, n_boot=5_000, seed=20260929,
                                      pair_key='pair', dataset_key='dataset', query_key='qkey'):
    """Uncertainty for a *fixed, prespecified roster* of pair×dataset cells.

    Queries are resampled with replacement within dataset, and the same query weights are applied to every
    qualified pair in that dataset. This preserves the dependence created by evaluating many pairs on the same
    query sample. The roster itself is not resampled, so the interval does not generalize to an imaginary population
    of retrieval systems.
    """
    if not rows:
        return {'estimate': float('nan'), 'ci95': (float('nan'), float('nan')), 'n_pairs': 0, 'n_datasets': 0}
    by_pair = defaultdict(list)
    q_by_ds = defaultdict(set)
    for r in rows:
        by_pair[r[pair_key]].append(r)
        q_by_ds[r[dataset_key]].add(r[query_key])
    def share(weights=None):
        hits = []
        for pair, rr in by_pair.items():
            if weights is None:
                vals = [float(x[value_key]) for x in rr]
                m = float(np.mean(vals)) if vals else float('nan')
            else:
                num = den = 0.0
                for x in rr:
                    w = weights.get((x[dataset_key], x[query_key]), 0)
                    num += w * float(x[value_key]); den += w
                if den == 0:
                    continue
                m = num / den
            hits.append(m >= threshold)
        return float(np.mean(hits)) if hits else float('nan')
    est = share()
    rng = np.random.default_rng(seed); boots = []
    ds_lists = {d: sorted(qs) for d, qs in q_by_ds.items()}
    for _ in range(n_boot):
        weights = {}
        for d, qs in ds_lists.items():
            draw = rng.integers(0, len(qs), len(qs))
            cnt = np.bincount(draw, minlength=len(qs))
            for i, q in enumerate(qs):
                weights[(d, q)] = int(cnt[i])
        boots.append(share(weights))
    return {'estimate': est, 'ci95': (float(np.quantile(boots, .025)), float(np.quantile(boots, .975))),
            'n_pairs': len(by_pair), 'n_datasets': len(q_by_ds), 'threshold': threshold,
            'scope': 'fixed prespecified roster; uncertainty from query sampling only'}


def cohen_kappa(a, b):
    a = np.asarray(a); b = np.asarray(b); labels = sorted(set(a) | set(b))
    po = float((a == b).mean())
    pe = sum(float((a == l).mean()) * float((b == l).mean()) for l in labels)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0
