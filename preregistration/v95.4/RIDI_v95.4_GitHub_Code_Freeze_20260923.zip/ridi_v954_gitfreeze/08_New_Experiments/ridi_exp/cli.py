"""Common command-line options."""
import argparse
import json
from pathlib import Path

from .backends import make_backend
from .io import read_jsonl
from .scoring import load_scorer, score


def base_parser(desc):
    ap = argparse.ArgumentParser(description=desc)
    ap.add_argument('--contexts', type=Path, required=True, help='context JSONL (schema in ridi_exp/io.py)')
    ap.add_argument('--out', type=Path, required=True, help='output directory')
    ap.add_argument('--backend', default='mock', choices=['mock', 'hf', 'vllm', 'openai', 'anthropic', 'gemini'])
    ap.add_argument('--model', default=None)
    ap.add_argument('--revision', default=None, help='immutable model revision (hf/vllm)')
    ap.add_argument('--max-new-tokens', type=int, default=128)
    ap.add_argument('--workers', type=int, default=8, help='parallel API requests')
    ap.add_argument('--frozen-scorer', type=Path, default=None, help='path to the registered scorer module (recommended)')
    ap.add_argument('--tolerant-parser', action='store_true', help='wrapper-tolerant verdict parser (sensitivity only)')
    ap.add_argument('--limit', type=int, default=None, help='first N queries only (pilot)')
    ap.add_argument('--mock-batch-noise', type=float, default=0.0, help=argparse.SUPPRESS)
    return ap


def backend_from(a):
    if a.backend == 'mock':
        return make_backend('mock', a.model, batch_noise=a.mock_batch_noise)
    if a.backend in ('hf', 'vllm'):
        return make_backend(a.backend, a.model, revision=a.revision, max_new_tokens=a.max_new_tokens)
    return make_backend(a.backend, a.model, max_new_tokens=a.max_new_tokens, workers=a.workers)


def scorer_from(a):
    if a.frozen_scorer:
        return load_scorer(a.frozen_scorer)
    return lambda c, raw: score(c, raw, tolerant=a.tolerant_parser)


def load_contexts(a, conditions=None):
    ctx = read_jsonl(a.contexts)
    if conditions:
        ctx = [c for c in ctx if c['condition'] in conditions]
    if a.limit:
        keep = sorted({c['qid'] for c in ctx})[:a.limit]
        ctx = [c for c in ctx if c['qid'] in set(keep)]
    return ctx


def dump(obj, path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=lambda x: list(x) if isinstance(x, tuple) else str(x)))
