"""Prompt construction. ALWAYS prefer the exact frozen prompt from the registered archive (context['prompt']).
The fallback template below is only for new datasets (P5) and for offline tests; record which one was used."""

QA_TEMPLATE = (
    "Answer the question using the passages. Reply with the short answer only.\n\n"
    "{passages}\n\nQuestion: {question}\nAnswer:"
)
VERDICT_TEMPLATE = (
    "Use the passages to classify the claim. Reply with exactly one label: SUPPORTS, REFUTES, or NOT_ENOUGH_INFO.\n\n"
    "{passages}\n\nClaim: {question}\nLabel:"
)


def format_passages(passages, max_chars=None):
    out = []
    for i, p in enumerate(passages, 1):
        text = p['text'] if max_chars is None else p['text'][:max_chars]
        title = p.get('title')
        out.append(f"[{i}] {title + ': ' if title else ''}{text}")
    return "\n\n".join(out)


def build_prompt(context, max_chars=None):
    if context.get('prompt'):
        return context['prompt'], 'frozen'
    tpl = QA_TEMPLATE if context['task'] == 'qa' else VERDICT_TEMPLATE
    return tpl.format(passages=format_passages(context['passages'], max_chars), question=context['question']), 'fallback_template'
