"""Generation backends. Every backend exposes
    generate_batches(batches: list[list[str]]) -> list[list[str]]
so the caller controls batch composition (needed for the execution-noise floor, P2).
API backends ignore batching (each request is independent) and run requests concurrently.

Backends: mock (offline tests), hf (transformers; exact batch control), vllm (throughput), openai, anthropic, gemini.
All use greedy / temperature-0 decoding. Record the returned metadata (model fingerprint, revision) in results.
"""
import hashlib
import os
import random
import time
from concurrent.futures import ThreadPoolExecutor


class Backend:
    name = 'base'
    meta = {}

    def generate_batches(self, batches):
        raise NotImplementedError


# ---------------------------------------------------------------- offline mock
class MockBackend(Backend):
    """Deterministic stand-in for tests. The answer depends on the prompt hash; with probability `batch_noise`
    it also depends on batch companions, mimicking floating-point batch effects."""
    name = 'mock'

    def __init__(self, model='mock-llm', batch_noise=0.0, answers=('SUPPORTS', 'REFUTES'), seed=0):
        self.model = model
        self.batch_noise = batch_noise
        self.answers = answers
        self.seed = seed
        self.meta = {'model': model, 'batch_noise': batch_noise}

    def _one(self, prompt, companions):
        h = int(hashlib.sha256((str(self.seed) + prompt).encode()).hexdigest(), 16)
        if self.batch_noise and (h % 1000) / 1000 < self.batch_noise:
            h ^= int(hashlib.sha256('|'.join(sorted(companions)).encode()).hexdigest(), 16)
        if 'Return exactly one token:' in prompt and 'EQUIVALENT' in prompt and 'DIFFERENT' in prompt:
            return 'EQUIVALENT' if h % 4 == 0 else 'DIFFERENT'
        if 'Reply with exactly one word: YES or NO' in prompt:
            return 'YES' if h % 4 == 0 else 'NO'
        if 'Are the two answers equivalent' in prompt:
            return 'YES' if h % 3 == 0 else 'NO'
        if 'Verdict:' in prompt:
            return self.answers[h % len(self.answers)]
        # QA: echo a word from the passages, deterministic in content
        words = [w.strip('.,:;') for w in prompt.split('Question:')[0].split() if w.isalpha() and len(w) > 3]
        return words[h % len(words)] if words else 'unknown'

    def generate_batches(self, batches):
        return [[self._one(p, b) for p in b] for b in batches]


# ---------------------------------------------------------------- transformers (exact batch control)
class HFBackend(Backend):
    name = 'hf'

    def __init__(self, model, revision=None, max_new_tokens=128, dtype='bfloat16', enable_thinking=False, deterministic=True):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        if deterministic:
            torch.use_deterministic_algorithms(True, warn_only=True)
            torch.backends.cuda.matmul.allow_tf32 = False
            torch.backends.cudnn.allow_tf32 = False
            os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(model, revision=revision, padding_side='left')
        if self.tok.pad_token is None:
            self.tok.pad_token = self.tok.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(model, revision=revision, torch_dtype=getattr(torch, dtype), device_map='auto')
        self.model.eval()
        self.max_new_tokens = max_new_tokens
        self.enable_thinking = enable_thinking
        self.meta = {'model': model, 'revision': revision, 'dtype': dtype, 'max_new_tokens': max_new_tokens,
                     'torch': torch.__version__, 'deterministic': deterministic}

    def _chat(self, prompt):
        msgs = [{'role': 'user', 'content': prompt}]
        try:
            return self.tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True, enable_thinking=self.enable_thinking)
        except TypeError:
            return self.tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)

    def generate_batches(self, batches):
        out = []
        for b in batches:
            enc = self.tok([self._chat(p) for p in b], return_tensors='pt', padding=True).to(self.model.device)
            with self.torch.no_grad():
                gen = self.model.generate(**enc, max_new_tokens=self.max_new_tokens, do_sample=False, temperature=None, top_p=None, top_k=None)
            new = gen[:, enc['input_ids'].shape[1]:]
            out.append([t.strip() for t in self.tok.batch_decode(new, skip_special_tokens=True)])
        return out


# ---------------------------------------------------------------- vLLM (throughput; batch composition not controlled)
class VLLMBackend(Backend):
    name = 'vllm'

    def __init__(self, model, revision=None, max_new_tokens=128, enable_thinking=False, seed=20260902, **kw):
        from vllm import LLM, SamplingParams
        self.llm = LLM(model=model, revision=revision, seed=seed, dtype='bfloat16', **kw)
        self.sp = SamplingParams(temperature=0.0, max_tokens=max_new_tokens)
        self.enable_thinking = enable_thinking
        self.meta = {'model': model, 'revision': revision, 'max_new_tokens': max_new_tokens,
                     'batch_invariant_env': os.environ.get('VLLM_BATCH_INVARIANT', '0')}

    def generate_batches(self, batches):
        flat = [p for b in batches for p in b]
        msgs = [[{'role': 'user', 'content': p}] for p in flat]
        try:
            outs = self.llm.chat(msgs, self.sp, chat_template_kwargs={'enable_thinking': self.enable_thinking})
        except TypeError:
            outs = self.llm.chat(msgs, self.sp)
        texts = [o.outputs[0].text.strip() for o in outs]
        res, i = [], 0
        for b in batches:
            res.append(texts[i:i + len(b)]); i += len(b)
        return res


# ---------------------------------------------------------------- API backends
class _APIBackend(Backend):
    def __init__(self, model, max_new_tokens=128, workers=8, retries=6):
        self.model = model
        self.max_new_tokens = max_new_tokens
        self.workers = workers
        self.retries = retries
        self.meta = {'model': model, 'max_new_tokens': max_new_tokens, 'provider': self.name}
        self.fingerprints = set()

    def _call(self, prompt):
        raise NotImplementedError

    def _safe(self, prompt):
        delay = 2.0
        for attempt in range(self.retries):
            try:
                return self._call(prompt)
            except Exception as e:  # rate limits and transient errors
                if attempt == self.retries - 1:
                    return f'__ERROR__ {type(e).__name__}: {e}'
                time.sleep(delay + random.random()); delay *= 2

    def generate_batches(self, batches):
        flat = [p for b in batches for p in b]
        with ThreadPoolExecutor(self.workers) as ex:
            texts = list(ex.map(self._safe, flat))
        self.meta['fingerprints'] = sorted(self.fingerprints)
        res, i = [], 0
        for b in batches:
            res.append(texts[i:i + len(b)]); i += len(b)
        return res


class OpenAIBackend(_APIBackend):
    name = 'openai'

    def __init__(self, model, **kw):
        super().__init__(model, **kw)
        from openai import OpenAI
        self.client = OpenAI()
        self.use_temperature = True

    def _call(self, prompt):
        args = dict(model=self.model, messages=[{'role': 'user', 'content': prompt}], seed=20260902)
        if self.use_temperature:
            args.update(temperature=0, max_tokens=self.max_new_tokens)
        else:
            args.update(max_completion_tokens=max(self.max_new_tokens, 1024))
        try:
            r = self.client.chat.completions.create(**args)
        except Exception as e:
            if self.use_temperature and ('temperature' in str(e) or 'max_tokens' in str(e)):
                self.use_temperature = False  # reasoning models: record that temperature was not settable
                self.meta['temperature_unsupported'] = True
                return self._call(prompt)
            raise
        if getattr(r, 'system_fingerprint', None):
            self.fingerprints.add(r.system_fingerprint)
        return (r.choices[0].message.content or '').strip()


class AnthropicBackend(_APIBackend):
    name = 'anthropic'

    def __init__(self, model, **kw):
        super().__init__(model, **kw)
        import anthropic
        self.client = anthropic.Anthropic()

    def _call(self, prompt):
        r = self.client.messages.create(model=self.model, max_tokens=self.max_new_tokens, temperature=0,
                                        messages=[{'role': 'user', 'content': prompt}])
        return ''.join(b.text for b in r.content if getattr(b, 'type', '') == 'text').strip()


class GeminiBackend(_APIBackend):
    name = 'gemini'

    def __init__(self, model, **kw):
        super().__init__(model, **kw)
        from google import genai
        self.client = genai.Client()

    def _call(self, prompt):
        r = self.client.models.generate_content(model=self.model, contents=prompt,
                                                config={'temperature': 0, 'max_output_tokens': self.max_new_tokens})
        return (r.text or '').strip()


def make_backend(kind, model=None, **kw):
    kinds = {'mock': MockBackend, 'hf': HFBackend, 'vllm': VLLMBackend, 'openai': OpenAIBackend,
             'anthropic': AnthropicBackend, 'gemini': GeminiBackend}
    if kind not in kinds:
        raise ValueError(f'unknown backend {kind}; choose from {sorted(kinds)}')
    if kind == 'mock':
        return MockBackend(model=model or 'mock-llm', **kw)
    return kinds[kind](model, **kw)
