#!/usr/bin/env python3
"""Validates an exported context file before any generation.

Checks: schema; the registered panel sizes (250 NQ, 250 HotpotQA, 150 FEVER, 150 SciFact) when --registered-panel is
given; one reference and one random draw-0 context per query; identical grade-by-rank vectors between reference and
every random draw; positively graded passages at the same ranks; presence of the frozen prompt string; duplicates.
Exit code 1 on any failure."""
import argparse
import sys
from collections import Counter, defaultdict

from ridi_exp.io import grade_vector, read_jsonl, validate_context

PANEL = {'nq': 250, 'hotpotqa': 250, 'fever': 150, 'scifact': 150}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('contexts'); ap.add_argument('--registered-panel', action='store_true')
    ap.add_argument('--require-prompt', action='store_true', help='fail if any context lacks the frozen prompt string')
    a = ap.parse_args()
    rows = read_jsonl(a.contexts); errors = []
    by = defaultdict(dict)
    for c in rows:
        try:
            validate_context(c)
        except ValueError as e:
            errors.append(str(e)); continue
        key = (c['condition'], c.get('draw', 0))
        if key in by[c['qid']]:
            errors.append(f"duplicate {c['qid']} {key}")
        by[c['qid']][key] = c
        if a.require_prompt and not c.get('prompt'):
            errors.append(f"{c['qid']} {key} has no frozen prompt")
    for q, d in by.items():
        ref = d.get(('reference', 0))
        if ref is None:
            errors.append(f'{q}: no reference'); continue
        for key, c in d.items():
            if key[0] == 'random':
                if grade_vector(c) != grade_vector(ref):
                    errors.append(f'{q} {key}: grade-by-rank vector differs from reference')
                for i, (p, r) in enumerate(zip(c['passages'], ref['passages'])):
                    if r.get('grade', 0) > 0 and p['docid'] != r['docid']:
                        errors.append(f'{q} {key}: positive passage moved at rank {i + 1}')
    ds = Counter(next(iter(d.values()))['dataset'] for d in by.values())
    print(f'{len(rows)} contexts, {len(by)} queries, datasets {dict(ds)}')
    if a.registered_panel and dict(ds) != PANEL:
        errors.append(f'panel sizes {dict(ds)} differ from registered {PANEL}')
    if errors:
        print(f'{len(errors)} problems; first 20:'); print('\n'.join(errors[:20])); sys.exit(1)
    print('OK')


if __name__ == '__main__':
    main()
