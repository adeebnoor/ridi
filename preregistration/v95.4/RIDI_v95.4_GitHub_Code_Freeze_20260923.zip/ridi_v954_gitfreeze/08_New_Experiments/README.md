# New experiments P1-P6: pre-registration code (v95.4 recovery lock)

**بالعربية باختصار:** هذا المجلد يحتوي على كود ما قبل التسجيل لتجارب P1-P6. تم اختبار **النواة التحليلية ومسارات P1-P5
بعد تجاوز طبقة retrieval/reranker الاختيارية** ببيانات اصطناعية وmock backend (`python tests/test_pipeline.py`)، كما تم اختبار P6
على أرشيف EPSS لعام 2023 فأعاد أرقام الورقة نفسها (565 و0 و7 و412/511). أما adapters الحقيقية لـ Pyserini /
rank_bm25 / sentence-transformers والنماذج/API الحقيقية فلم تُشغّل في هذا الفحص. لا يبدأ أي توليد حقيقي قبل إيداع OSF؛
المسودة المنقحة هي `04_Prospective_Protocol/OSF_Preregistration_P1-P6_v95.4_REVIEWED.md`.

## What has and has not been tested

| Component | Tested here | Not tested here |
| --- | --- | --- |
| Statistics (paired accuracy, TOST, McNemar, Wilson, Holm, bootstraps, kappa) | Unit tests reproduce the paper's values (for example +1.75 points, P = 0.012) | - |
| P1-P5 core | P1-P4 mock paths plus P5 qualification → contexts → generation → analysis on dependency-free synthetic pools/rankings | P5 real retrieval/reranker adapters; real BEIR corpora; real models/APIs |
| P6 EPSS | Reproduces 565 / 0 / 7 / 412 / 511 and the 8 to 12 KEV counts on the archived 2023 files | The 2026 v4 to v5 files (download needed) |
| API and GPU backends | Code paths written against current client libraries | Live calls; check the first pilot outputs by eye |

**Do not run a real-model pilot before the OSF registration is filed**: a pilot creates new outcomes and would cross the preregistration boundary.
The `--limit 20` advice applies only after registration. Before registration, run offline/mock tests and input/provenance checks only.

## Setup

```
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # add vllm, pyserini, sentence-transformers as needed
python -m pytest -q tests/test_pipeline.py  # currently: 2 passed
python tests/test_pipeline.py               # must print ALL OFFLINE CORE TESTS PASSED
```

The dependency-free offline test does **not** validate the real retrieval adapters. After installing the full environment, separately smoke-test `pool`/`rerank` on a tiny frozen dataset before the registered run, without inspecting any confirmatory model outcome.

The registered 800-query reference+random contexts have been recovered from the original OSF package plus the archived prepared inputs/results, validated with zero identity/grade-vector mismatches, and stored at `data/contexts_800.jsonl`. Verify them with:

```
python check_contexts.py data/contexts_800.jsonl --registered-panel --require-prompt
```

Use the recovered registered scorer at `frozen_registered/scoring.py` (SHA-256 `5b9f02f7...8488c7ee`). The loader adapts its historical `canonical_answer()` and `is_correct()` interface without changing the scoring rules. The built-in scorer in `ridi_exp/scoring.py` remains fallback-only.

## Run order, cost and what each produces

| Step | Command (after OSF filing; pilot first with `--limit 20` where supported) | Compute (rough; measure in the pilot) | Output |
| --- | --- | --- | --- |
| P2 execution-noise floor | `python p2_noise_floor.py --contexts data/contexts_800.jsonl --out results/p2 --backend hf --model Qwen/Qwen3-8B --revision b968826d9c46dd6066d109eabc6255188de91218 --frozen-scorer S --archived data/registered_generations_primary_800.jsonl` | 6,400 generations; about 2-4 GPU-hours (A100) | `P2_summary.json`: floors, excess over floor, byte identity with the registered outputs |
| P1 frontier model | `python p1_frontier_model.py --contexts data/contexts_800.jsonl --out results/p1_<model> --backend openai\|anthropic\|gemini --model <exact id> --repeats 3 --frozen-scorer S` | 4,800 calls per model | `P1_summary.json`: change rate, repeat floor, excess, paired accuracy and TOST |
| P3 replacement draws | `python make_replacement_draws.py --pools data/pools_800.jsonl --registered data/contexts_800.jsonl --out data/draws.jsonl --draws 4` then `python p3_multi_draw.py --contexts data/draws.jsonl --out results/p3 --backend hf --model Qwen/Qwen3-8B --revision ...` | 4,800 generations; about 2 GPU-hours | `P3_summary.json`: rate per draw, share of queries changing in any or most draws |
| P4 semantic audit | `python p4_semantic_audit.py --stage judge ... --judge1 openai:<id> --judge2 anthropic:<id>`; `--stage export`; two annotators fill the CSVs; `--stage analyze --generations results/p2/generations.jsonl` | about 30,000 short judge calls (about 14,000 exchanged passages x 2 judges); 2 annotator-days | `P4_summary.json`: kappas, judge miss rate, change rate in the clean subset |
| P5 natural prevalence | `pool` then `rerank` then `qualify` then `contexts` then `generate` (per generator) then `analyze` (see `python p5_natural_prevalence.py -h`; roster: `p5_roster_template.yaml`) | Reranking: a few GPU-hours. Generation: (queries in the estimation split) x (configurations in qualified pairs) x 2 runs per generator | `P5_summary_<tag>.json`: fixed-roster share of equivalent pairs whose excess disagreement is at least 5 points, query-resampling CI, descriptive mean bootstrap, association with Jaccard distance |
| P6 EPSS v4 to v5 | `python p6_epss_v4_v5.py scan --scores DIR` then `run --scores DIR --kev KEV.csv --before D1 --after D2 --out results/p6` | CPU, minutes | `P6_summary.json`: turnover, frontier, 30/60/90-day KEV capture |

## P5 practical notes

- Primary confirmatory datasets: `nq`, `hotpotqa`, `fever`, `scifact`. `fiqa` and `trec-covid` are secondary transport analyses and are not counted in H-P5.
- Download the frozen datasets in BEIR format.
  For `nq` and `hotpotqa` use Pyserini prebuilt indexes (`--pyserini-index beir-v1.0.0-{dataset}.flat`); rank_bm25 is
  too slow for multi-million-document corpora.
- Exclude the 800 registered queries: `--exclude data/registered_qids.txt` (one `dataset:qid` per line).
- Pin every model revision in the roster (the script refuses unpinned models unless `--allow-unpinned` is passed for a pilot).
- Natural Questions and HotpotQA answers are not part of BEIR; pass `--answers` with the independently sourced answers
  used in the registered study, or rely on the answer-disagreement endpoint only.
- For FEVER/SciFact, build contexts with `--verdict-labels`; the locked P5 prompt has three labels (SUPPORTS/REFUTES/NOT_ENOUGH_INFO).
- The locked P5 generation truncates each passage to 1,200 Unicode characters (`--max-chars-per-passage 1200`).
- The primary endpoint is answer disagreement between configurations, minus the repeat floor. Use `--semantic-judge`
  in `analyze` so that differently worded but equivalent answers are not counted as disagreement; audit a sample of
  the judge's decisions by hand.
- Generate with at least two open generators and one API model (`--tag qwen8b`, `--tag llama8b`, `--tag api`).

## P6 note on registration

OSF `7cah9` was verified through the public OSF API: it was registered on 25 August 2026, after EPSS v5 (15 June 2026), and explicitly labels v2–v5 retrospective while locking the next post-v5 release. Therefore P6 v4→v5 is retrospective/descriptive. The KEV snapshot is pinned in `06_Provenance/P6_KEV_SNAPSHOT_LOCK_v95.4.json`.

## What to send back for the manuscript update

All `*_summary.json` files, the P5 `P5_rows_<tag>.csv` files, the OSF registration link and date, the exact model
identifiers and revisions, and any deviation from the registration.
