#!/usr/bin/env python3
"""P3. Variation across replacement draws.

Generates reference and every random draw (from make_replacement_draws.py) and reports
  * correctness-change rate per draw (macro and pooled) and its spread across draws
  * distribution of the number of draws (out of D+1) in which a query's correctness changed
  * fraction of queries that change in at least one draw, and in a majority of draws
  * per-query change probability, its mean, and an intraclass-style share of variance between queries

Use the same backend, revision and batch regime as the registered run (fixed:16 by default) so that
differences across draws are attributable to the exchanged passages.
"""
from collections import Counter, defaultdict

import numpy as np

from ridi_exp import analysis, stats
from ridi_exp.cli import backend_from, base_parser, dump, load_contexts, scorer_from
from ridi_exp.io import read_jsonl
from ridi_exp.runner import run_generation


def main():
    ap = base_parser(__doc__)
    ap.add_argument('--regime', default='fixed:16')
    ap.add_argument('--analyze-only', action='store_true')
    a = ap.parse_args()
    out = a.out / 'generations.jsonl'
    ctx = load_contexts(a, conditions={'reference', 'random'})
    if not a.analyze_only:
        run_generation(ctx, backend_from(a), out, run=0, regime=a.regime, scorer=scorer_from(a))
    res = read_jsonl(out); model = res[0]['model']; idx = analysis.index(res)
    draws = sorted({r['draw'] for r in res if r['condition'] == 'random'})
    ref = idx[(model, 0, a.regime, 'reference', 0)]
    per_draw = {}; changes = defaultdict(list)
    for d in draws:
        var = idx[(model, 0, a.regime, 'random', d)]
        c = analysis.contrast(ref, var)[0]
        per_draw[d] = {'macro': c['correctness_change_macro'], 'pooled': c['correctness_change_pooled'], 'n': c['n']}
        for q in set(ref) & set(var):
            changes[q].append(int(ref[q]['correct'] != var[q]['correct']))
    full = {q: v for q, v in changes.items() if len(v) == len(draws)}
    counts = Counter(sum(v) for v in full.values())
    probs = np.array([np.mean(v) for v in full.values()])
    # share of variance between queries (binary outcomes): var(p_q) / (mean p (1 - mean p))
    pbar = probs.mean() if len(probs) else float('nan')
    between = float(probs.var() / (pbar * (1 - pbar))) if 0 < pbar < 1 else float('nan')
    S = {'experiment': 'P3', 'model': model, 'draws': draws, 'per_draw': per_draw,
         'pooled_rate_range': [min(v['pooled'] for v in per_draw.values()), max(v['pooled'] for v in per_draw.values())],
         'n_queries_all_draws': len(full),
         'distribution_changed_draws': {int(k): int(v) for k, v in sorted(counts.items())},
         'fraction_change_any_draw': float(np.mean([sum(v) > 0 for v in full.values()])),
         'fraction_change_majority': float(np.mean([sum(v) > len(v) / 2 for v in full.values()])),
         'mean_per_query_change_probability': float(pbar), 'between_query_variance_share': between}
    dump(S, a.out / 'P3_summary.json')
    print(f"P3 {model}: per-draw pooled {S['pooled_rate_range']}; any draw {100*S['fraction_change_any_draw']:.1f}%; "
          f"majority {100*S['fraction_change_majority']:.1f}%")


if __name__ == '__main__':
    main()
