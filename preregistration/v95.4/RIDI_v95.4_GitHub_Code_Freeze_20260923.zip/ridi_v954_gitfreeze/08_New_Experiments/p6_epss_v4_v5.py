#!/usr/bin/env python3
"""P6. EPSS version 4 to version 5 transition (June 2026) with matched-horizon outcomes.

REGISTRATION STATUS VERIFIED 23 September 2026: OSF 7cah9 was registered on 25 August 2026, after EPSS v5
(15 June 2026). Its registration explicitly treats v2-v5 analyses as retrospective and prospectively locks only the
next release after v5. Therefore this v4-to-v5 analysis is retrospective/descriptive and must not be described as
prospective confirmation under 7cah9.

Steps
  1. Download daily files around the release, e.g. for d in 2026-06-0{1..9} ...:
       https://epss.empiricalsecurity.com/epss_scores-YYYY-MM-DD.csv.gz    (mirror: github.com/empiricalsec/epss_scores)
     and the current KEV catalogue: https://www.cisa.gov/sites/default/files/csv/known_exploited_vulnerabilities.csv
  2. python p6_epss_v4_v5.py scan --scores DIR                       # finds the model_version change
  3. python p6_epss_v4_v5.py run --scores DIR --kev KEV.csv --before YYYY-MM-DD --after YYYY-MM-DD --out results/p6

Outputs: turnover at k in {100, 500, 1000, 5000} for the update and adjacent same-version days; the exact frontier under
the probability objective at the registered tolerance ladder; KEV additions within 30, 60 and 90 days after the update
(the 30-day window matches the EPSS forecast horizon) for the previous, updated and constrained selections; Wilson
intervals for retention; SHA-256 of every input file.
"""
import argparse
import csv
import datetime as dt
import gzip
import hashlib
import json
import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / '05_Reproduction'))
from run_probability_frontier import frontier, wilson  # noqa: E402  (same exact implementation as the paper)

ETAS = ['0', '0.0001', '0.001', '0.005', '0.01', '0.05']


def header(path):
    with gzip.open(path, 'rt') as fh:
        first = fh.readline().strip()
    return dict(x.split(':', 1) for x in first.lstrip('#').split(',') if ':' in x)


def load(path):
    with gzip.open(path, 'rt') as fh:
        return {r['cve'].strip(): Decimal(r['epss']) for r in csv.DictReader(l for l in fh if not l.startswith('#'))}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fpath(d, day):
    return Path(d) / f'epss_scores-{day}.csv.gz'


def top(scores, ids, k):
    return set(sorted(ids, key=lambda x: (-scores[x], x))[:k])


def cmd_scan(a):
    files = sorted(Path(a.scores).glob('epss_scores-*.csv.gz'))
    prev = None
    for f in files:
        h = header(f); v = h.get('model_version')
        flag = ' <-- version change' if prev and v != prev else ''
        print(f'{f.name}  model_version={v}{flag}'); prev = v


def cmd_run(a):
    b = dt.date.fromisoformat(a.before); u = dt.date.fromisoformat(a.after)
    days = {'before_minus_1': b - dt.timedelta(days=1), 'before': b, 'after': u, 'after_plus_1': u + dt.timedelta(days=1)}
    paths = {k: fpath(a.scores, d.isoformat()) for k, d in days.items()}
    for k, p in paths.items():
        if not p.exists():
            raise SystemExit(f'missing {p}')
    versions = {k: header(p).get('model_version') for k, p in paths.items()}
    if versions['before'] == versions['after']:
        raise SystemExit(f'no version change between {a.before} and {a.after}: {versions}')
    S = {k: load(p) for k, p in paths.items()}
    kev = {}
    with open(a.kev, encoding='utf-8') as fh:
        for r in csv.DictReader(fh):
            kev[r['cveID'].strip()] = dt.date.fromisoformat(r['dateAdded'])
    ids = set.intersection(*(set(s) for s in S.values())) - {c for c, d in kev.items() if d <= b}
    ids = sorted(ids)
    out = {'inputs': {k: {'file': str(p.name), 'sha256': sha(p), 'model_version': versions[k]} for k, p in paths.items()},
           'kev_sha256': sha(a.kev), 'kev_latest_dateAdded': max(kev.values()).isoformat(), 'universe': len(ids),
           'turnover': {}, 'frontier': [], 'outcomes': {}}
    for k in a.k:
        sel = {n: top(S[n], ids, k) for n in S}
        out['turnover'][k] = {'update': k - len(sel['before'] & sel['after']),
                              'same_version_before': k - len(sel['before_minus_1'] & sel['before']),
                              'same_version_after': k - len(sel['after'] & sel['after_plus_1'])}
    k = a.primary_k
    old = top(S['before'], ids, k); new = top(S['after'], ids, k)
    scale = 10 ** 5
    util = {c: int(S['after'][c] * scale) for c in ids}
    inside, outside, vals = frontier(ids, old, util, k)
    ustar = max(vals)
    windows = {w: {c for c, d in kev.items() if u < d <= u + dt.timedelta(days=w)} for w in a.windows}
    complete = {w: (u + dt.timedelta(days=w)) <= max(kev.values()) for w in a.windows}
    def capture(sel):
        return {w: len(sel & windows[w]) for w in a.windows}
    base_hits = capture(new)
    out['outcomes'] = {'previous_selection': capture(old), 'updated_selection': base_hits, 'window_complete_in_kev_file': complete,
                       'pool_additions': {w: len(set(ids) & windows[w]) for w in a.windows}}
    for eta in ETAS:
        e = Decimal(eta)
        j = min(jj for jj, v in enumerate(vals) if Decimal(ustar - v) <= e * ustar)
        sel = set(inside[:k - j]) | set(outside[:j])
        hits = capture(sel)
        ret = {w: len(sel & new & windows[w]) for w in a.windows}
        out['frontier'].append({'eta': eta, 'replacements': j, 'avoided': (k - len(old & new)) - j,
                                'probability_sum': vals[j] / scale, 'relative_loss': float((ustar - vals[j]) / ustar),
                                'kev_hits': hits, 'retained_of_updated_hits': ret,
                                'retention_wilson': {w: wilson(ret[w], base_hits[w]) for w in a.windows}})
    out['unconstrained_probability_sum'] = ustar / scale
    Path(a.out).mkdir(parents=True, exist_ok=True)
    (Path(a.out) / 'P6_summary.json').write_text(json.dumps(out, indent=2, default=str))
    t = out['turnover'][k]; f1 = next(f for f in out['frontier'] if f['eta'] == '0.001')
    print(f"P6: universe {len(ids)}; update replaced {t['update']} of {k} (same-version {t['same_version_before']}, {t['same_version_after']}); "
          f"0.1% tolerance needs {f1['replacements']}; KEV {out['outcomes']}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    s = sub.add_parser('scan'); s.add_argument('--scores', required=True)
    s = sub.add_parser('run'); s.add_argument('--scores', required=True); s.add_argument('--kev', required=True)
    s.add_argument('--before', required=True); s.add_argument('--after', required=True); s.add_argument('--out', required=True)
    s.add_argument('--k', type=int, nargs='+', default=[100, 500, 1000, 5000]); s.add_argument('--primary-k', type=int, default=1000)
    s.add_argument('--windows', type=int, nargs='+', default=[30, 60, 90])
    a = ap.parse_args()
    {'scan': cmd_scan, 'run': cmd_run}[a.cmd](a)


if __name__ == '__main__':
    main()
