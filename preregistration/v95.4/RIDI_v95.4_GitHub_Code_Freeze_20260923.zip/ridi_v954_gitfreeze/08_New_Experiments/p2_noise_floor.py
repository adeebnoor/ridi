#!/usr/bin/env python3
"""P2. Execution-noise floor for a local model (default Qwen3-8B at the registered revision).

Generates reference and random (draw 0) contexts under four batch regimes:
  single            one prompt per forward pass; matches the registered execution structure
  fixed:16          deterministic batch companions
  shuffled:16:1     different companions
  shuffled:16:2     different companions again
Reports, for each regime, the primary contrast; the floor as reference-vs-reference disagreement across regimes;
and excess change = contrast - floor with a stratified bootstrap interval. Optionally compares the fixed-regime
reference outputs with the archived registered outputs (--archived) to confirm byte identity.

Example (GPU):
  python p2_noise_floor.py --contexts data/contexts_800.jsonl --out results/p2_qwen8b --backend hf \
      --model Qwen/Qwen3-8B --revision b968826d9c46dd6066d109eabc6255188de91218 --frozen-scorer path/to/scorer.py
"""
import itertools

from ridi_exp import analysis, stats
from ridi_exp.cli import backend_from, base_parser, dump, load_contexts, scorer_from
from ridi_exp.io import read_jsonl
from ridi_exp.runner import run_generation

REGIMES = ['single', 'fixed:16', 'shuffled:16:1', 'shuffled:16:2']


def main():
    ap = base_parser(__doc__)
    ap.add_argument('--regimes', nargs='+', default=REGIMES)
    ap.add_argument('--archived', default=None, help='archived registered generations JSONL with qid, condition, raw')
    ap.add_argument('--analyze-only', action='store_true')
    a = ap.parse_args()
    out = a.out / 'generations.jsonl'
    ctx = [c for c in load_contexts(a, conditions={'reference', 'random'}) if c.get('draw', 0) == 0]
    if not a.analyze_only:
        be = backend_from(a); sc = scorer_from(a)
        for g in a.regimes:
            run_generation(ctx, be, out, run=0, regime=g, scorer=sc)
    res = read_jsonl(out); model = res[0]['model']; idx = analysis.index(res)
    S = {'experiment': 'P2', 'model': model, 'regimes': a.regimes, 'contrast_by_regime': {}, 'floors': {}, 'excess': {}}
    for g in a.regimes:
        S['contrast_by_regime'][g] = analysis.contrast(idx[(model, 0, g, 'reference', 0)], idx[(model, 0, g, 'random', 0)])[0]
    for g1, g2 in itertools.combinations(a.regimes, 2):
        for cond in ('reference', 'random'):
            c = analysis.contrast(idx[(model, 0, g1, cond, 0)], idx[(model, 0, g2, cond, 0)])[0]
            S['floors'][f'{cond}:{g1}|{g2}'] = {'correctness_change_pooled': c['correctness_change_pooled'],
                                                'canonical_change_pooled': c['canonical_change_pooled']}
    # primary excess: contrast in the registered-equivalent single-prompt regime against
    # the reference floor single vs fixed:16; shuffled regimes are prespecified sensitivities.
    if len(a.regimes) >= 2:
        g0, g1 = a.regimes[0], a.regimes[1]
        S['excess']['primary'] = analysis.contrast_with_floor(idx, model, 'reference', 'random', (0, g0), (0, g1))
        # worst-case floor: max over regime pairs of reference disagreement, per query
        A = idx[(model, 0, g0, 'reference', 0)]; B = idx[(model, 0, g0, 'random', 0)]
        worst = {}
        for q in A:
            worst[q] = max(int(idx[(model, 0, x, 'reference', 0)].get(q, A[q])['correct'] != idx[(model, 0, y, 'reference', 0)].get(q, A[q])['correct'])
                           for x, y in itertools.combinations(a.regimes, 2))
        change = {q: int(A[q]['correct'] != B[q]['correct']) for q in A if q in B}
        S['excess']['against_worst_case_floor'] = stats.excess_over_floor(change, worst, strata={q: A[q]['dataset'] for q in A})
    if a.archived:
        arch = {(r['qid'], r['condition']): r['raw'] for r in read_jsonl(a.archived)}
        g0 = a.regimes[0]; same = tot = 0
        for cond in ('reference', 'random'):
            for q, r in idx[(model, 0, g0, cond, 0)].items():
                if (q, cond) in arch:
                    tot += 1; same += int(arch[(q, cond)] == r['raw'])
        S['archived_byte_identity'] = {'regime': g0, 'identical': same, 'compared': tot}
    dump(S, a.out / 'P2_summary.json')
    e = S['excess'].get('primary', {}).get('excess_correctness', {})
    print(f"P2 {model}: primary contrast {100*S['contrast_by_regime'][a.regimes[0]]['correctness_change_pooled']:.2f}% pooled; "
          f"excess over floor {100*e.get('excess', float('nan')):.2f} pp CI {e.get('ci95')}")


if __name__ == '__main__':
    main()
