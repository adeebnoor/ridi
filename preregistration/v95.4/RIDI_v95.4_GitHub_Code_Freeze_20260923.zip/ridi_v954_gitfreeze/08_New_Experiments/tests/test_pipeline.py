#!/usr/bin/env python3
"""Offline end-to-end test of P1-P5 with synthetic data and the mock backend, plus unit tests of the statistics.
Run from 08_New_Experiments:  python tests/test_pipeline.py
No GPU, network or API key is needed. Passing this test shows the code paths run and the statistics are correct on
known inputs; it says nothing about real model behaviour."""
import json
import os
import random
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from ridi_exp import stats  # noqa: E402
from ridi_exp.io import append_jsonl, read_jsonl  # noqa: E402
from ridi_exp.prompts import VERDICT_TEMPLATE  # noqa: E402
from p5_natural_prevalence import split_of  # noqa: E402

WORK = HERE / 'tests' / '_work'
WORDS = ('alpha beta gamma delta epsilon zeta theta iota kappa lambda sigma omega river mountain forest ocean '
         'protein kinase tumour inhibitor receptor vaccine treaty empire harbour castle comet planet signal').split()


def run(*args):
    r = subprocess.run([sys.executable, *args], cwd=HERE, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout, r.stderr); raise SystemExit(f'FAILED: {args}')
    return r.stdout


def test_stats():
    # reproduces the paper's pooled Qwen3-8B numbers from 60 correct->wrong and 74 wrong->correct among 800
    ref = [1] * 60 + [0] * 74 + [1] * 300 + [0] * 366
    var = [0] * 60 + [1] * 74 + [1] * 300 + [0] * 366
    pa = stats.paired_accuracy(ref, var)
    assert pa['correct_to_wrong'] == 60 and pa['wrong_to_correct'] == 74
    assert abs(100 * pa['diff'] - 1.75) < 1e-9
    assert abs(100 * pa['ci90'][0] + 0.628) < 0.01 and abs(100 * pa['ci90'][1] - 4.128) < 0.01
    assert abs(pa['mcnemar_p'] - 0.2614) < 1e-3
    assert abs(stats.tost_p(pa['diff'], pa['se'], 0.05) - 0.0123) < 1e-3
    lo, hi = stats.wilson(12, 12); assert abs(lo - 0.7575) < 1e-3 and hi == 1.0
    assert stats.holm([0.01, 0.04, 0.03]) == [0.03, 0.06, 0.06]
    assert abs(stats.cohen_kappa([1, 0, 1, 0], [1, 0, 1, 0]) - 1) < 1e-12
    t = stats.paired_tost([0.5] * 50, [0.5] * 50, 0.01); assert t['equivalent']
    assert 'NOT_ENOUGH_INFO' in VERDICT_TEMPLATE
    rr = [
        {'dataset':'d','qkey':'d|q1','pair':'d|a|b','excess':0.10},
        {'dataset':'d','qkey':'d|q2','pair':'d|a|b','excess':0.10},
        {'dataset':'d','qkey':'d|q1','pair':'d|a|c','excess':0.00},
        {'dataset':'d','qkey':'d|q2','pair':'d|a|c','excess':0.00},
    ]
    fb = stats.fixed_roster_pair_share_bootstrap(rr, n_boot=100, seed=1)
    assert abs(fb['estimate'] - 0.5) < 1e-12 and fb['n_pairs'] == 2
    print('stats: ok')


def synth_contexts(n_per=20):
    rng = random.Random(1); rows = []; pools = []
    for ds, task in (('scifact', 'verdict'), ('nq', 'qa')):
        for i in range(n_per):
            qid = f'{ds}-{i}'
            pool = [{'docid': f'{qid}-d{j}', 'text': ' '.join(rng.choice(WORDS) for _ in range(20)), 'grade': 1 if j == 0 else 0} for j in range(40)]
            gold = ['SUPPORTS' if i % 2 else 'REFUTES'] if task == 'verdict' else [pool[0]['text'].split()[3]]
            q = {'qid': qid, 'dataset': ds, 'task': task, 'question': f'question {i} about {rng.choice(WORDS)}', 'gold': gold}
            ref = pool[:10]
            ran = [ref[0]] + rng.sample(pool[10:], 9)
            rows.append(dict(q, condition='reference', draw=0, passages=ref))
            rows.append(dict(q, condition='random', draw=0, passages=ran))
            pools.append(dict(q, k=10, pool=pool))
    return rows, pools


def synth_p5_inputs(work, n_per_dataset=60):
    """Build dependency-free synthetic P5 pools/rankings.

    This intentionally bypasses the retrieval/reranker adapters so the core qualification,
    context construction, prompt generation and analysis are tested without rank_bm25,
    Pyserini or sentence-transformers.
    """
    rng = random.Random(20260928)
    pools, ranks = [], []
    for ds in ('toy1', 'toy2'):
        for i in range(n_per_dataset):
            qid = f'{ds}:q{i}'
            docs = []
            for j in range(20):
                docs.append({'docid': f'{qid}-d{j}', 'bm25': float(20-j), 'title': '',
                             'text': ' '.join(rng.choice(WORDS) for _ in range(24)),
                             'grade': 1 if j == 0 else 0})
            pools.append({'qid': qid, 'dataset': ds, 'question': f'question {i} {rng.choice(WORDS)}',
                          'split': split_of(qid, 20260928), 'task': 'qa', 'gold': ['__no_gold__'],
                          'qrels': {docs[0]['docid']: 1}, 'pool': docs})
            base = [d['docid'] for d in docs]
            # a and b are exactly equivalent on retrieval metrics; c deliberately moves the relevant doc.
            bad = base[1:11] + [base[0]] + base[11:]
            ranks.extend([
                {'qid': qid, 'dataset': ds, 'config': 'a', 'ranking': base},
                {'qid': qid, 'dataset': ds, 'config': 'b', 'ranking': base},
                {'qid': qid, 'dataset': ds, 'config': 'c', 'ranking': bad},
            ])
    append_jsonl(work / 'pools.jsonl', pools)
    append_jsonl(work / 'rankings.jsonl', ranks)


def exercise_p5_core(work):
    work.mkdir(parents=True, exist_ok=True)
    synth_p5_inputs(work)
    out = run('p5_natural_prevalence.py', 'qualify', '--work', str(work), '--margin', '0.05')
    pairs = json.load(open(work / 'pairs.json'))
    assert any(p['a'] == 'a' and p['b'] == 'b' for p in pairs['qualified'])
    run('p5_natural_prevalence.py', 'contexts', '--work', str(work))
    run('p5_natural_prevalence.py', 'generate', '--work', str(work), '--backend', 'mock', '--tag', 'mock', '--regime', 'shuffle-per-run')
    run('p5_natural_prevalence.py', 'analyze', '--work', str(work), '--tag', 'mock', '--semantic-judge', 'mock:judge')
    summary = json.load(open(work / 'P5_summary_mock.json'))
    assert summary['n_pairs_analyzed'] >= 1
    assert 'share_pairs_meeting_threshold_point_query_bootstrap' in summary
    generations = read_jsonl(work / 'generations_mock.jsonl')
    assert generations and all(r.get('prompt_sha256') for r in generations)
    assert all(r.get('prompt_max_chars_per_passage') == 1200 for r in generations)
    return out, summary


def test_p5_core_without_retrieval_dependencies(tmp_path):
    exercise_p5_core(tmp_path / 'p5')


def main():
    test_stats()
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)
    ctx, pools = synth_contexts()
    append_jsonl(WORK / 'contexts.jsonl', ctx); append_jsonl(WORK / 'pools.jsonl', pools)
    # P1 (mock API-like, 3 repeats)
    print(run('p1_frontier_model.py', '--contexts', str(WORK / 'contexts.jsonl'), '--out', str(WORK / 'p1'), '--backend', 'mock', '--model', 'mock-api', '--repeats', '3').strip().splitlines()[-1])
    s = json.load(open(WORK / 'p1' / 'P1_summary.json')); assert s['per_run_contrast']['0']['n'] == 40
    # P2 (mock with batch noise so the floor is non-zero)
    print(run('p2_noise_floor.py', '--contexts', str(WORK / 'contexts.jsonl'), '--out', str(WORK / 'p2'), '--backend', 'mock', '--model', 'mock-local', '--mock-batch-noise', '1.0').strip().splitlines()[-1])
    s = json.load(open(WORK / 'p2' / 'P2_summary.json'))
    assert any(v['correctness_change_pooled'] > 0 for v in s['floors'].values()), 'batch noise should create a floor'
    # P3
    run('make_replacement_draws.py', '--pools', str(WORK / 'pools.jsonl'), '--out', str(WORK / 'draws.jsonl'), '--draws', '4')
    print(run('p3_multi_draw.py', '--contexts', str(WORK / 'draws.jsonl'), '--out', str(WORK / 'p3'), '--backend', 'mock').strip().splitlines()[-1])
    s = json.load(open(WORK / 'p3' / 'P3_summary.json')); assert len(s['draws']) == 4 and s['n_queries_all_draws'] == 40
    # P4
    run('p4_semantic_audit.py', '--stage', 'judge', '--contexts', str(WORK / 'contexts.jsonl'), '--out', str(WORK / 'p4'))
    run('p4_semantic_audit.py', '--stage', 'export', '--contexts', str(WORK / 'contexts.jsonl'), '--out', str(WORK / 'p4'), '--n-human', '30')
    assert (WORK / 'p4' / 'human_audit_manifest.json').exists()
    for ann in ('annotator_A', 'annotator_B'):  # simulate annotations
        p = WORK / 'p4' / f'human_audit_{ann}.csv'; lines = p.read_text().splitlines()
        rng = random.Random(ann)
        p.write_text('\n'.join([lines[0]] + [l.replace(',,', f",{'YES' if rng.random() < .3 else 'NO'},", 1) if l.count(',,') else l for l in lines[1:]]) + '\n')
    print(run('p4_semantic_audit.py', '--stage', 'analyze', '--contexts', str(WORK / 'contexts.jsonl'), '--out', str(WORK / 'p4'),
              '--generations', str(WORK / 'p2' / 'generations.jsonl'), '--regime', 'fixed:16').strip().splitlines()[-1])
    s = json.load(open(WORK / 'p4' / 'P4_summary.json')); assert 'change_all' in s and s['n_passages_judged'] > 0
    # P5 core (dependency-free synthetic pools/rankings; retrieval adapters are tested separately once optional deps are installed)
    qout, _ = exercise_p5_core(WORK / 'p5')
    print(qout.strip())
    print('ALL OFFLINE CORE TESTS PASSED')


if __name__ == '__main__':
    main()
