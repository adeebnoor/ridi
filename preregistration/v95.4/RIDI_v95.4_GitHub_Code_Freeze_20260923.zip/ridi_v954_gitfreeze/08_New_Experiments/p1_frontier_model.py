#!/usr/bin/env python3
"""P1. Frontier (API) model on the registered 800-query reference-vs-exchanged contrast, with repeats.

Runs `--repeats` independent passes over reference and random contexts (draw 0), then reports:
  * correctness and normalized-answer change, macro (registered estimand) and pooled, with stratified bootstrap
  * repeat floor: reference run 0 vs reference run 1 (the model's own nondeterminism)
  * excess change over the floor, paired accuracy difference, TOST at 3 and 5 points, McNemar

Example:
  python p1_frontier_model.py --contexts data/contexts_800.jsonl --out results/p1_gpt \
      --backend openai --model <exact model id> --repeats 3 --frozen-scorer path/to/scorer.py
"""
from ridi_exp import analysis
from ridi_exp.cli import backend_from, base_parser, dump, load_contexts, scorer_from
from ridi_exp.io import read_jsonl
from ridi_exp.runner import run_generation


def main():
    ap = base_parser(__doc__)
    ap.add_argument('--repeats', type=int, default=3)
    ap.add_argument('--regime', default='api', help="'api' for API backends; e.g. fixed:16 for local models")
    ap.add_argument('--analyze-only', action='store_true')
    a = ap.parse_args()
    out = a.out / 'generations.jsonl'
    ctx = load_contexts(a, conditions={'reference', 'random'})
    ctx = [c for c in ctx if c.get('draw', 0) == 0]
    if not a.analyze_only:
        be = backend_from(a); sc = scorer_from(a)
        for r in range(a.repeats):
            regime = a.regime if a.regime != 'api' else 'fixed:32'
            run_generation(ctx, be, out, run=r, regime=regime, scorer=sc)
    res = read_jsonl(out)
    if not res:
        raise SystemExit('no results')
    model = res[0]['model']; regime = res[0]['batch_regime']
    idx = analysis.index(res)
    summary = {'experiment': 'P1', 'model': model, 'n_contexts': len(ctx),
               'errors': sum(1 for r in res if str(r['raw']).startswith('__ERROR__')),
               'primary_vs_run1_floor': analysis.contrast_with_floor(idx, model, 'reference', 'random', (0, regime), (1, regime)) if len({r['run'] for r in res}) > 1 else None}
    runs = sorted({r['run'] for r in res})
    summary['per_run_contrast'] = {r: analysis.contrast(idx[(model, r, regime, 'reference', 0)], idx[(model, r, regime, 'random', 0)])[0] for r in runs}
    floors = {}
    for i in runs:
        for j in runs:
            if i < j:
                floors[f'{i}-{j}'] = analysis.contrast(idx[(model, i, regime, 'reference', 0)], idx[(model, j, regime, 'reference', 0)])[0]['correctness_change_pooled']
    summary['reference_repeat_floors_pooled'] = floors
    dump(summary, a.out / 'P1_summary.json')
    m = summary['per_run_contrast'][runs[0]]
    print(f"P1 {model}: correctness change macro {100*m['correctness_change_macro']:.2f}% pooled {100*m['correctness_change_pooled']:.2f}%; "
          f"repeat floors {floors}")


if __name__ == '__main__':
    main()
