#!/usr/bin/env python3
"""Builds additional replacement draws (P3) from the frozen top-100 retrieval pools.

Pool JSONL, one line per query:
  {"qid", "dataset", "task", "question", "gold", "k": 10,
   "pool": [{"docid", "text", "grade"}, ...]}        # frozen top-100 in rank order, grades from the benchmark qrels

For each query and draw d = 1..D: keep every positively graded passage of the reference top-k at its rank and fill
each grade-zero position with a distinct grade-zero passage drawn from pool positions k+1..100 (seeded by qid and d),
exactly as in the registered construction. The grade-by-rank vector is checked to be identical to the reference.
Writes contexts with condition 'reference' (draw 0) and 'random' (draws 1..D). When the pool export contains the
registered prompt template, each new context receives the exact frozen prompt string. Use --registered to append the
registered draw-0 'random' contexts unchanged so that draw 0 is the original, not a re-draw.
"""
import argparse
import hashlib
import random
from pathlib import Path

from ridi_exp.io import append_jsonl, grade_vector, read_jsonl


def frozen_prompt(pool_row, passages):
    tpl = pool_row.get('prompt_template')
    if not tpl:
        return None
    pchars = int(pool_row.get('passage_chars', 1200))
    body = '\n\n'.join(f'[{i+1}] {p["text"][:pchars]}' for i, p in enumerate(passages))
    return tpl.format(passages=body, query=pool_row['question'])


def seed_for(qid, draw, base):
    return int(hashlib.sha256(f'{base}|{qid}|{draw}'.encode()).hexdigest()[:16], 16)


def build(pool_row, draws, base_seed):
    k = pool_row.get('k', 10); pool = pool_row['pool']
    ref = pool[:k]
    zero_pos = [i for i, p in enumerate(ref) if p.get('grade', 0) == 0]
    cands = [p for p in pool[k:] if p.get('grade', 0) == 0]
    common = {x: pool_row[x] for x in ('qid', 'dataset', 'task', 'question', 'gold')}
    out = [dict(common, condition='reference', draw=0, passages=ref, prompt=frozen_prompt(pool_row, ref))]
    if len(cands) < len(zero_pos):
        return out, 'insufficient_candidates'
    for d in range(1, draws + 1):
        rng = random.Random(seed_for(pool_row['qid'], d, base_seed))
        chosen = rng.sample(cands, len(zero_pos))
        ctx = list(ref)
        for pos, new in zip(zero_pos, chosen):
            ctx[pos] = new
        c = dict(common, condition='random', draw=d, passages=ctx, prompt=frozen_prompt(pool_row, ctx))
        assert grade_vector(c) == grade_vector(out[0]), 'grade-by-rank vector changed'
        assert len({p['docid'] for p in ctx}) == len(ctx), 'duplicate passage'
        out.append(c)
    return out, 'ok'


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--pools', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--draws', type=int, default=4, help='new draws in addition to the registered draw 0')
    ap.add_argument('--seed', type=int, default=20260925)
    ap.add_argument('--registered', type=Path, default=None, help='registered contexts JSONL; its random draw-0 rows are kept')
    a = ap.parse_args()
    if a.out.exists():
        raise SystemExit(f'{a.out} exists; refusing to overwrite')
    status = {'ok': 0, 'insufficient_candidates': 0}; rows = []
    for p in read_jsonl(a.pools):
        r, s = build(p, a.draws, a.seed); status[s] += 1; rows += r
    if a.registered:
        rows += [c for c in read_jsonl(a.registered) if c['condition'] == 'random' and c.get('draw', 0) == 0]
    append_jsonl(a.out, rows)
    print(f'wrote {len(rows)} contexts; status {status}')


if __name__ == '__main__':
    main()
