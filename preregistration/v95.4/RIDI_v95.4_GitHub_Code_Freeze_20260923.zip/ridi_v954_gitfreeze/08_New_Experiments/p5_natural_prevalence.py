#!/usr/bin/env python3
"""P5. Natural prevalence within a prespecified finite roster: how often do distinct retrieval configurations that are statistically
equivalent on a benchmark lead a fixed model to different answers?

Subcommands (run in order; every step writes into --work):
  pool      Sample previously unused queries, retrieve a common BM25 top-100 pool, split 40/60 into qualification and
            estimation sets by a seeded hash.
  rerank    Score every pooled candidate with every configuration in the roster (YAML) and store each top-10.
  qualify   On the qualification split only, test every configuration pair within each dataset for equivalence in
            nDCG@10 and Recall@10 (paired TOST, margin 0.01) with Holm correction. No generator output is read.
  contexts  Build generation contexts (estimation split) for every configuration that appears in a qualified pair.
  generate  Generate answers with the runner (two runs per context for the repeat floor).
  analyze   Pair-level answer disagreement, repeat floor, excess, share of qualified pairs whose excess is at least
            5 points, a query-resampling interval for the fixed-roster share, descriptive two-way bootstrap for mean
            excess, and the association with Jaccard distance.

Data: BEIR-format directories <beir>/<dataset>/{corpus.jsonl, queries.jsonl, qrels/test.tsv}. For large corpora
(Natural Questions, HotpotQA) use a Pyserini prebuilt index (--pyserini-index beir-v1.0.0-<dataset>.flat); rank_bm25
is used otherwise and is suitable only for small corpora. Optional gold answers: JSONL {"qid", "answers": [...]}.

Freeze the roster, margins, split, sample sizes and analysis before any generation, and register them at OSF.
"""
import argparse
import csv
import hashlib
import itertools
import json
import math
import random
from collections import defaultdict
from pathlib import Path

import numpy as np

from ridi_exp import stats
from ridi_exp.io import append_jsonl, read_jsonl


# ------------------------------------------------------------------ data
def load_beir(root):
    root = Path(root)
    corpus = {}
    for r in read_jsonl(root / 'corpus.jsonl'):
        corpus[str(r['_id'])] = {'title': r.get('title', ''), 'text': r.get('text', '')}
    queries = {str(r['_id']): r['text'] for r in read_jsonl(root / 'queries.jsonl')}
    qrels = defaultdict(dict)
    with open(root / 'qrels' / 'test.tsv', encoding='utf-8') as fh:
        rd = csv.reader(fh, delimiter='\t'); next(rd)
        for q, d, s in rd:
            qrels[str(q)][str(d)] = int(s)
    return corpus, queries, qrels


def split_of(qid, seed, frac_qualify=0.4):
    h = int(hashlib.sha256(f'{seed}|{qid}'.encode()).hexdigest()[:12], 16) / 16 ** 12
    return 'qualify' if h < frac_qualify else 'estimate'


class BM25Pool:
    def __init__(self, corpus, pyserini_index=None):
        self.corpus = corpus
        if pyserini_index:
            from pyserini.search.lucene import LuceneSearcher
            self.searcher = LuceneSearcher.from_prebuilt_index(pyserini_index); self.mode = 'pyserini'
        else:
            from rank_bm25 import BM25Okapi
            self.ids = list(corpus)
            self.bm = BM25Okapi([(corpus[i]['title'] + ' ' + corpus[i]['text']).lower().split() for i in self.ids]); self.mode = 'rank_bm25'

    def search(self, query, k=100):
        if self.mode == 'pyserini':
            hits = self.searcher.search(query, k)
            out = []
            for h in hits:
                doc = self.corpus.get(h.docid)
                if doc is None:
                    raw = json.loads(self.searcher.doc(h.docid).raw()); doc = {'title': raw.get('title', ''), 'text': raw.get('text', raw.get('contents', ''))}
                out.append((h.docid, float(h.score), doc))
            return out
        sc = self.bm.get_scores(query.lower().split())
        top = np.argsort(-sc, kind='stable')[:k]
        return [(self.ids[i], float(sc[i]), self.corpus[self.ids[i]]) for i in top]


# ------------------------------------------------------------------ metrics
def ndcg_at_k(ranked, rel, k=10):
    dcg = sum((2 ** rel.get(d, 0) - 1) / math.log2(i + 2) for i, d in enumerate(ranked[:k]))
    ideal = sorted(rel.values(), reverse=True)[:k]
    idcg = sum((2 ** g - 1) / math.log2(i + 2) for i, g in enumerate(ideal))
    return dcg / idcg if idcg > 0 else 0.0


def recall_at_k(ranked, rel, k=10):
    pos = {d for d, g in rel.items() if g > 0}
    return len(pos & set(ranked[:k])) / len(pos) if pos else 0.0


def jaccard_distance(a, b):
    a, b = set(a), set(b)
    return 1 - len(a & b) / len(a | b) if a | b else 0.0


# ------------------------------------------------------------------ scorers
def make_scorer(cfg, cache):
    t = cfg['type']
    if t == 'bm25':
        return lambda q, cands: [c['bm25'] for c in cands]
    if t == 'synthetic':  # offline tests only: BM25 plus seeded noise
        rng_seed = cfg.get('seed', 0); sd = cfg.get('noise', 1.0)
        def f(q, cands):
            return [c['bm25'] + random.Random(f"{rng_seed}|{q['qid']}|{c['docid']}").gauss(0, sd) for c in cands]
        return f
    if t == 'biencoder':
        from sentence_transformers import SentenceTransformer
        m = cache.setdefault(cfg['model'], SentenceTransformer(cfg['model'], revision=cfg.get('revision')))
        qp, dp = cfg.get('query_prefix', ''), cfg.get('doc_prefix', '')
        norm = cfg.get('normalize', True)
        def f(q, cands):
            qe = m.encode([qp + q['question']], normalize_embeddings=norm)
            de = m.encode([dp + (c['title'] + ' ' + c['text']).strip() for c in cands], normalize_embeddings=norm, batch_size=64)
            return (de @ qe[0]).tolist()
        return f
    if t == 'sparse':  # SPLADE-style models via sentence-transformers >= 5 SparseEncoder
        from sentence_transformers import SparseEncoder
        m = cache.setdefault(cfg['model'], SparseEncoder(cfg['model'], revision=cfg.get('revision')))
        def f(q, cands):
            qe = m.encode_query([q['question']])
            de = m.encode_document([(c['title'] + ' ' + c['text']).strip() for c in cands], batch_size=32)
            return [float(x) for x in m.similarity(qe, de)[0]]
        return f
    if t == 'crossencoder':
        from sentence_transformers import CrossEncoder
        m = cache.setdefault(cfg['model'], CrossEncoder(cfg['model'], revision=cfg.get('revision'), max_length=cfg.get('max_length', 512)))
        return lambda q, cands: [float(x) for x in m.predict([(q['question'], (c['title'] + ' ' + c['text']).strip()) for c in cands], batch_size=64)]
    raise ValueError(f'unknown configuration type {t}')


def rrf(rankings, k=60):
    score = defaultdict(float)
    for r in rankings:
        for i, d in enumerate(r):
            score[d] += 1 / (k + i + 1)
    return [d for d, _ in sorted(score.items(), key=lambda x: (-x[1], x[0]))]


# ------------------------------------------------------------------ subcommands
def cmd_pool(a):
    excluded = set()
    if a.exclude:
        excluded = {l.strip() for l in open(a.exclude) if l.strip()}
    answers = {}
    if a.answers:
        answers = {r['qid']: r['answers'] for r in read_jsonl(a.answers)}
    out = a.work / 'pools.jsonl'
    if out.exists():
        raise SystemExit(f'{out} exists')
    for ds in a.datasets:
        corpus, queries, qrels = load_beir(Path(a.beir) / ds)
        idx_name = a.pyserini_index.replace('{dataset}', ds) if a.pyserini_index else None
        pool = BM25Pool(corpus, idx_name)
        eligible = sorted(q for q in qrels if q in queries and f'{ds}:{q}' not in excluded and q not in excluded)
        random.Random(f'{a.seed}|{ds}').shuffle(eligible)
        chosen = eligible[:a.n_per_dataset]
        rows = []
        for q in chosen:
            hits = pool.search(queries[q], a.depth)
            rows.append({'qid': f'{ds}:{q}', 'dataset': ds, 'question': queries[q], 'split': split_of(f'{ds}:{q}', a.seed),
                         'task': 'verdict' if ds in ('scifact', 'fever', 'climate-fever') and a.verdict_labels else 'qa',
                         'gold': answers.get(f'{ds}:{q}', answers.get(q, [])),
                         'qrels': qrels[q],
                         'pool': [{'docid': d, 'bm25': s, 'title': doc.get('title', ''), 'text': doc.get('text', ''), 'grade': qrels[q].get(d, 0)} for d, s, doc in hits]})
        append_jsonl(out, rows)
        print(f'{ds}: {len(rows)} queries pooled ({sum(r["split"] == "qualify" for r in rows)} qualification) with {pool.mode}')


def cmd_rerank(a):
    import yaml
    roster = yaml.safe_load(open(a.roster))['configurations']
    names = [c['name'] for c in roster]
    if len(set(names)) != len(names):
        raise SystemExit('duplicate configuration names')
    pools = read_jsonl(a.work / 'pools.jsonl'); out = a.work / 'rankings.jsonl'
    done = {(r['qid'], r['config']) for r in read_jsonl(out)}; cache = {}
    unpinned = [c['name'] for c in roster if c['type'] in ('biencoder', 'crossencoder', 'sparse') and (not c.get('revision') or str(c.get('revision')).startswith('PIN'))]
    if unpinned and not a.allow_unpinned:
        raise SystemExit(f'pin an immutable revision (commit hash) for: {unpinned}  (or pass --allow-unpinned for a pilot)')
    base = [c for c in roster if c['type'] != 'rrf']; fused = [c for c in roster if c['type'] == 'rrf']
    for cfg in base:
        f = make_scorer(cfg, cache); rows = []
        for p in pools:
            if (p['qid'], cfg['name']) in done:
                continue
            q = {'qid': p['qid'], 'question': p['question']}
            sc = f(q, p['pool'])
            order = sorted(range(len(sc)), key=lambda i: (-sc[i], p['pool'][i]['docid']))
            rows.append({'qid': p['qid'], 'dataset': p['dataset'], 'config': cfg['name'], 'ranking': [p['pool'][i]['docid'] for i in order]})
        append_jsonl(out, rows); print(f"{cfg['name']}: {len(rows)} queries ranked")
    ranks = defaultdict(dict)
    for r in read_jsonl(out):
        ranks[r['qid']][r['config']] = r['ranking']
    rows = []
    for cfg in fused:
        for p in pools:
            if (p['qid'], cfg['name']) in done:
                continue
            rows.append({'qid': p['qid'], 'dataset': p['dataset'], 'config': cfg['name'],
                         'ranking': rrf([ranks[p['qid']][m] for m in cfg['members']], cfg.get('k', 60))})
    append_jsonl(out, rows)
    manifest = {'roster': roster, 'n_queries': len(pools)}
    (a.work / 'roster_manifest.json').write_text(json.dumps(manifest, indent=2))


def per_query_metrics(pools, rankings, split):
    ranks = defaultdict(dict)
    for r in rankings:
        ranks[r['qid']][r['config']] = r['ranking']
    M = defaultdict(lambda: defaultdict(dict))  # dataset -> config -> qid -> (ndcg, recall)
    for p in pools:
        if p['split'] != split:
            continue
        rel = {d: g for d, g in p['qrels'].items()}
        for cfg, r in ranks[p['qid']].items():
            M[p['dataset']][cfg][p['qid']] = (ndcg_at_k(r, rel), recall_at_k(r, rel))
    return M, ranks


def cmd_qualify(a):
    pools = read_jsonl(a.work / 'pools.jsonl'); M, _ = per_query_metrics(pools, read_jsonl(a.work / 'rankings.jsonl'), 'qualify')
    allpairs = []
    for ds, cfgs in M.items():
        names = sorted(cfgs)
        for x, y in itertools.combinations(names, 2):
            q = sorted(set(cfgs[x]) & set(cfgs[y]))
            tn = stats.paired_tost([cfgs[x][k][0] for k in q], [cfgs[y][k][0] for k in q], a.margin)
            tr = stats.paired_tost([cfgs[x][k][1] for k in q], [cfgs[y][k][1] for k in q], a.margin)
            allpairs.append({'dataset': ds, 'a': x, 'b': y, 'n': len(q), 'ndcg_diff': tn['mean_diff'], 'ndcg_ci90': tn['ci90'], 'ndcg_p': tn['p'],
                             'recall_diff': tr['mean_diff'], 'recall_ci90': tr['ci90'], 'recall_p': tr['p'], 'p_joint': max(tn['p'], tr['p'])})
    for ds in {p['dataset'] for p in allpairs}:
        sub = [p for p in allpairs if p['dataset'] == ds]
        for p, adj in zip(sub, stats.holm([p['p_joint'] for p in sub])):
            p['p_holm'] = adj; p['qualified'] = bool(adj < a.alpha)
    q = [p for p in allpairs if p['qualified']]
    (a.work / 'pairs.json').write_text(json.dumps({'margin': a.margin, 'alpha': a.alpha, 'all_pairs': allpairs, 'qualified': q}, indent=2))
    print(f'{len(q)} of {len(allpairs)} configuration pairs qualified as equivalent (margin {a.margin}, Holm alpha {a.alpha})')


def cmd_contexts(a):
    pools = {p['qid']: p for p in read_jsonl(a.work / 'pools.jsonl')}
    pairs = json.load(open(a.work / 'pairs.json'))
    use = defaultdict(set)
    for p in (pairs['all_pairs'] if a.all_configs else pairs['qualified']):
        use[p['dataset']] |= {p['a'], p['b']}
    rows = []
    for r in read_jsonl(a.work / 'rankings.jsonl'):
        p = pools[r['qid']]
        if p['split'] != 'estimate' or r['config'] not in use[p['dataset']]:
            continue
        docs = {d['docid']: d for d in p['pool']}
        rows.append({'qid': p['qid'], 'dataset': p['dataset'], 'task': p['task'], 'question': p['question'], 'gold': p['gold'] or ['__no_gold__'],
                     'condition': r['config'], 'config': r['config'], 'draw': 0,
                     'passages': [{'docid': d, 'title': docs[d]['title'], 'text': docs[d]['text'], 'grade': docs[d]['grade']} for d in r['ranking'][:a.k]]})
    out = a.work / 'contexts.jsonl'
    if out.exists():
        raise SystemExit(f'{out} exists')
    append_jsonl(out, rows); print(f'{len(rows)} contexts written for {sum(len(v) for v in use.values())} dataset-configurations')


def cmd_generate(a):
    from ridi_exp.backends import make_backend
    from ridi_exp.runner import run_generation
    ctx = read_jsonl(a.work / 'contexts.jsonl')
    be = make_backend(a.backend, a.model) if a.backend == 'mock' else (
        make_backend(a.backend, a.model, revision=a.revision, max_new_tokens=a.max_new_tokens) if a.backend in ('hf', 'vllm')
        else make_backend(a.backend, a.model, max_new_tokens=a.max_new_tokens, workers=a.workers))
    for r in range(a.repeats):
        run_generation(ctx, be, a.work / f'generations_{a.tag}.jsonl', run=r,
                       regime=a.regime if a.regime != 'shuffle-per-run' else f'shuffled:16:{r + 1}',
                       max_chars=a.max_chars_per_passage)


def cmd_analyze(a):
    pools = {p['qid']: p for p in read_jsonl(a.work / 'pools.jsonl')}
    pairs = json.load(open(a.work / 'pairs.json'))['qualified']
    ranks = defaultdict(dict)
    for r in read_jsonl(a.work / 'rankings.jsonl'):
        ranks[r['qid']][r['config']] = r['ranking'][:a.k]
    res = read_jsonl(a.work / f'generations_{a.tag}.jsonl')
    G = defaultdict(dict)  # (config, run) -> qid -> result
    for r in res:
        G[(r['condition'], r['run'])][r['qid']] = r
    judge = None
    judge_template = None
    if a.semantic_judge:
        from ridi_exp.backends import make_backend
        kind, model = a.semantic_judge.split(':', 1)
        if kind in ('hf', 'vllm'):
            judge = make_backend(kind, model, revision=a.semantic_judge_revision, max_new_tokens=8)
        elif kind == 'mock':
            judge = make_backend(kind, model)
        else:
            judge = make_backend(kind, model, max_new_tokens=8, workers=a.workers)
        judge_path = Path(a.semantic_judge_prompt) if a.semantic_judge_prompt else Path(__file__).with_name('P5_SEMANTIC_JUDGE_PROMPT_v95.3.txt')
        judge_template = judge_path.read_text(encoding='utf-8')
    cache_path = a.work / f'semantic_cache_{a.tag}.jsonl'
    cache = {(r['question'], r['x'], r['y']): r['equivalent'] for r in read_jsonl(cache_path)}

    def differ(q, x, y):
        if x == y:
            return 0
        if judge is None:
            return 1
        key = (q, *sorted([x, y]))
        if key not in cache:
            prompt = judge_template.format(question=q, answer_a=key[1], answer_b=key[2])
            out = judge.generate_batches([[prompt]])[0][0]
            label = out.strip().upper()
            equivalent = 1 if label == 'EQUIVALENT' else 0 if label == 'DIFFERENT' else None
            cache[key] = equivalent
            append_jsonl(cache_path, [{'question': key[0], 'x': key[1], 'y': key[2], 'equivalent': equivalent, 'raw': out}])
        if cache[key] is None:
            return None
        return 1 - cache[key]

    rows = []; pair_summ = []
    for p in pairs:
        A, B = p['a'], p['b']
        qs = [q for q in pools if pools[q]['dataset'] == p['dataset'] and pools[q]['split'] == 'estimate'
              and all(q in G[(c, r)] for c in (A, B) for r in (0, 1))]
        prow = []
        for q in qs:
            ques = pools[q]['question']
            dis = differ(ques, G[(A, 0)][q]['canonical'], G[(B, 0)][q]['canonical'])
            fl_a = differ(ques, G[(A, 0)][q]['canonical'], G[(A, 1)][q]['canonical'])
            fl_b = differ(ques, G[(B, 0)][q]['canonical'], G[(B, 1)][q]['canonical'])
            if dis is None or fl_a is None or fl_b is None:
                continue  # invalid judge output is missing, never silently disagreement/equivalence
            fl = (fl_a + fl_b) / 2
            has_gold = pools[q]['gold'] and pools[q]['gold'] != ['__no_gold__']
            row = {'qid': q, 'qkey': f"{p['dataset']}|{q}", 'pair': f"{p['dataset']}|{A}|{B}", 'dataset': p['dataset'],
                   'config_a': A, 'config_b': B, 'disagree': dis, 'floor': fl, 'excess': dis - fl,
                   'jaccard': jaccard_distance(ranks[q][A], ranks[q][B]),
                   'correct_change': int(G[(A, 0)][q]['correct'] != G[(B, 0)][q]['correct']) if has_gold else None}
            prow.append(row)
        rows += prow
        if prow:
            ex = np.array([r['excess'] for r in prow])
            rng = np.random.default_rng(20260927); boots = [ex[rng.integers(0, len(ex), len(ex))].mean() for _ in range(5000)]
            pair_summ.append({'pair': f"{p['dataset']}|{A}|{B}", 'n': len(prow), 'disagreement': float(np.mean([r['disagree'] for r in prow])),
                              'floor': float(np.mean([r['floor'] for r in prow])), 'excess': float(ex.mean()),
                              'excess_ci95': (float(np.quantile(boots, .025)), float(np.quantile(boots, .975))),
                              'mean_jaccard': float(np.mean([r['jaccard'] for r in prow])),
                              'meets_5pt_point': bool(ex.mean() >= a.threshold),
                              'meets_5pt_lower_bound': bool(np.quantile(boots, .025) >= a.threshold)})
    S = {'experiment': 'P5', 'tag': a.tag, 'n_qualified_pairs': len(pairs), 'n_pairs_analyzed': len(pair_summ), 'threshold': a.threshold,
         'semantic_judge': a.semantic_judge, 'semantic_judge_revision': a.semantic_judge_revision,
         'semantic_judge_prompt': a.semantic_judge_prompt, 'semantic_judge_failures': sum(v is None for v in cache.values()), 'pairs': pair_summ}
    if pair_summ:
        S['share_pairs_meeting_threshold_point'] = float(np.mean([p['meets_5pt_point'] for p in pair_summ]))
        S['share_pairs_meeting_threshold_lower_bound'] = float(np.mean([p['meets_5pt_lower_bound'] for p in pair_summ]))
        S['share_pairs_meeting_threshold_point_query_bootstrap'] = stats.fixed_roster_pair_share_bootstrap(
            rows, value_key='excess', threshold=a.threshold, query_key='qkey')
        S['mean_excess_two_way_bootstrap_descriptive'] = stats.two_way_cluster_bootstrap(rows, 'excess', unit_a='qkey')
        S['mean_disagreement_two_way_bootstrap_descriptive'] = stats.two_way_cluster_bootstrap(rows, 'disagree', unit_a='qkey')
        # association of disagreement with Jaccard distance (descriptive): linear slope with two-way bootstrap
        x = np.array([r['jaccard'] for r in rows]); y = np.array([r['disagree'] for r in rows])
        S['disagreement_by_jaccard_bin'] = {f'{lo:.1f}-{lo + 0.2:.1f}': (float(y[(x >= lo) & (x < lo + 0.2 + 1e-9)].mean()) if ((x >= lo) & (x < lo + 0.2 + 1e-9)).any() else None, int(((x >= lo) & (x < lo + 0.2 + 1e-9)).sum()))
                                        for lo in np.arange(0, 1.0, 0.2)}
        S['slope_disagreement_on_jaccard'] = float(np.polyfit(x, y, 1)[0]) if len(set(x)) > 1 else None
        cc = [r['correct_change'] for r in rows if r['correct_change'] is not None]
        S['correctness_change_rate_where_gold'] = float(np.mean(cc)) if cc else None
    (a.work / f'P5_summary_{a.tag}.json').write_text(json.dumps(S, indent=2))
    with open(a.work / f'P5_rows_{a.tag}.csv', 'w', newline='') as fh:
        if rows:
            w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"P5 {a.tag}: {S['n_pairs_analyzed']} pairs; share meeting {a.threshold:.0%} excess (point) = {S.get('share_pairs_meeting_threshold_point')}; "
          f"fixed-roster share CI {S.get('share_pairs_meeting_threshold_point_query_bootstrap')}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    s = sub.add_parser('pool'); s.add_argument('--beir', required=True); s.add_argument('--datasets', nargs='+', required=True)
    s.add_argument('--n-per-dataset', type=int, default=300); s.add_argument('--depth', type=int, default=100); s.add_argument('--seed', type=int, default=20260928)
    s.add_argument('--exclude', default=None, help='file of qids already used (the registered 800); one per line, dataset:qid or qid')
    s.add_argument('--answers', default=None); s.add_argument('--pyserini-index', default=None, help='e.g. beir-v1.0.0-{dataset}.flat')
    s.add_argument('--verdict-labels', action='store_true', help='treat fact-checking datasets as verdict tasks (requires gold labels)')
    s = sub.add_parser('rerank'); s.add_argument('--roster', required=True); s.add_argument('--allow-unpinned', action='store_true')
    s = sub.add_parser('qualify'); s.add_argument('--margin', type=float, default=0.01); s.add_argument('--alpha', type=float, default=0.05)
    s = sub.add_parser('contexts'); s.add_argument('--k', type=int, default=10); s.add_argument('--all-configs', action='store_true')
    s = sub.add_parser('generate'); s.add_argument('--backend', default='mock'); s.add_argument('--model', default=None); s.add_argument('--revision', default=None)
    s.add_argument('--repeats', type=int, default=2); s.add_argument('--regime', default='shuffle-per-run', help="default changes batch companions between runs so the repeat floor includes execution noise; use fixed:16 to hold them")
    s.add_argument('--max-new-tokens', type=int, default=128); s.add_argument('--max-chars-per-passage', type=int, default=1200,
                   help='deterministic per-passage truncation for P5 generation prompts (locked default: 1200 Unicode chars)')
    s.add_argument('--workers', type=int, default=8); s.add_argument('--tag', required=True)
    s = sub.add_parser('analyze'); s.add_argument('--tag', required=True); s.add_argument('--k', type=int, default=10); s.add_argument('--threshold', type=float, default=0.05)
    s.add_argument('--semantic-judge', default=None, help='backend:model used to judge whether two different answers are equivalent')
    s.add_argument('--semantic-judge-revision', default=None, help='immutable revision for hf/vllm semantic judge')
    s.add_argument('--semantic-judge-prompt', default=None, help='frozen semantic judge prompt template; defaults to P5_SEMANTIC_JUDGE_PROMPT_v95.3.txt')
    s.add_argument('--workers', type=int, default=8)
    for s in sub.choices.values():
        s.add_argument('--work', type=Path, required=True)
    a = ap.parse_args(); a.work.mkdir(parents=True, exist_ok=True)
    {'pool': cmd_pool, 'rerank': cmd_rerank, 'qualify': cmd_qualify, 'contexts': cmd_contexts, 'generate': cmd_generate, 'analyze': cmd_analyze}[a.cmd](a)


if __name__ == '__main__':
    main()
