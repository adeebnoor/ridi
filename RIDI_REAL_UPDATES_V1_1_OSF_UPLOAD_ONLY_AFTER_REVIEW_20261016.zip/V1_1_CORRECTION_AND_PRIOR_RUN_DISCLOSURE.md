# RIDI-REAL-UPDATES-v1.1: prospective technical correction and full restart

Prepared 16 October 2026. THIS IS A DRAFT, NOT A PUBLISHED REGISTRATION. NO SCIENTIFIC UNIT OF V1.1 HAS RUN.

Prior OSF registration https://osf.io/ras42/ archived the full V1 code and data. Before this proposed V1.1 lock, V1 pair 1 completed four model-by-condition units, each independently file-hash-audited with 800 records; results remain content-blind. The V1 attempt p3_incumbent__floor/attempt1 ended with status blocked, reason KeyError, retryable false. These five V1 attempts are not incorporated into V1.1 and shall not be overwritten, relabelled or reused. V1 remains INCOMPLETE, and P8 remains separately INCOMPLETE.

The V1 metadata error: registration/models.json omitted max_position_embeddings for p3_incumbent, p3_successor, p4_incumbent, p4_successor. V1 code/runner.py accessed this key and stopped at the first Llama unit. The V1 prelock tokenizer_preflight.json (12/12 PASS, 800 prompts each) had already determined the four correct model context limits: 8192, 131072, 8192, 131072 respectively.

The proposed V1.1 ONLY restores those four pre-observed metadata values, changes literal study identifiers, updates documentation and re-pins the execution output root to an entirely separate directory. Locked prompts, benchmark counts, passage contexts, frozen predictors, model IDs/revisions, GPU model/region and count, generation settings, scoring, hypotheses, bootstrap count/seed and analysis estimands remain unchanged. This does not convert V1 outcomes into V1.1 results.

The conservative, independently analyzable V1.1 plan is a complete new 24-unit run using only fresh outputs (12 exact pinned models x main/floor). Nothing may start before V1.1 has a complete newly created SHA-256 scientific lock, its immutable code/data/protocol are archived publicly under a NEW registration, and a public receipt with timestamp proves publication predates the first V1.1 scientific answer. OSF registration updates cannot replace V1 attached files, so V1.1 requires its own public attached archive and links to V1 ras42.

The V1.1 confirmatory status must always disclose pre-existing V1 attempts and their terminal state, that none of the case-level results was examined when preparing this technical correction, and that this correction was motivated by an observed software failure. Independent auditor must validate new V1.1 files before analysis; all original V1 records must remain separate and unopened until predeclared disclosure procedure.

Do NOT count any previous V1 successes toward the new 24 V1.1 units. Do not represent this document as preregistered until the new OSF approval and independent public file-hash checks are completed.
